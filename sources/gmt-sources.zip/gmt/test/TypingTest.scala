import glang.syntax._
import glang.Parser
import glang.syntax.Syntax._
import glang.typing._

class TypingTest extends munit.FunSuite {

  def formatInput(s: String): String = {
    symbols.foldLeft(s) {
      case (acc, s) => {
        acc.replace(s.pprint, s.parser)
      }
    }
  }

  def intrinsify(p: String) = {
    Parser.parse(formatInput(p)) match {
      case Right(term) => Typing(term)
    }

  }

  test("simple parse") {
    val t = intrinsify("(λx.x) : ★ -> int")
    assertEquals(t.tpe, FuncType(Unknown(), IntType()))
  }

  test("application of typed lambda") {
    val t = intrinsify("(λx.x) : ★ -> int 1")
    assertEquals(t.tpe, IntType())
  }
  test("application of untyped lambda") {
    val t = intrinsify("((λx.x) 1) + 1")
    assertEquals(t.tpe, IntType())
  }
  test("imprecise application of untyped lambda") {
    val t = intrinsify("((λx.x : ★) 1) + 1")
    assertEquals(t.tpe, IntType())
  }

  test("simple fix") {
    val t = intrinsify("(fix f. 1) : int")

    assertEquals(t.pprint, "((fix f. 1) : int)")
    assertEquals(t.tpe, IntType())
  }
  test("fix 2") {
    val t = intrinsify("(fix f. (λx. f x)) : int -> int")

    assertEquals(t.pprint, "((fix f. (λx. f x)) : int -> int)")
    assertEquals(t.tpe, FuncType(IntType(), IntType()))
  }

  test("fix 3") {
    val t =
      intrinsify("(fix f. (λx. if x==0 then 0 else f (x-1))) : int -> int")

    assertEquals(
      t.pprint,
      "((fix f. (λx. if x == 0 then 0 else f x - 1)) : int -> int)"
    )
    assertEquals(t.tpe, FuncType(IntType(), IntType()))
  }
}
