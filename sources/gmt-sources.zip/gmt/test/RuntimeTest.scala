import glang.typing.TypeDerivation._
import glang._
import glang.runtime.Runtime
import glang.syntax.Syntax._
import glang.typing._

class RuntimeTest extends munit.FunSuite {
  def formatInput(s: String): String = {
    symbols.foldLeft(s) {
      case (acc, s) => {
        acc.replace(s.pprint, s.parser)
      }
    }
  }

  def run(p: String): Option[TypeDerivation] = {
    Parser.parse(formatInput(p)) match {
      case Right(term) =>
        Runtime.Reducer(Typing(term), stepSize = 10000).reduce.r match {
          case Left(e)  => Some(e)
          case Right(_) => None
        }
    }
  }

  test("application of typed lambda") {
    val t = run("(λx.x) : int -> int 1")
    assertEquals(t, Some(INumber(1)))
  }

  test("application of untyped typed lambda") {
    val t = run("((λx.x) 1) + 1")
    assertEquals(t, Some(INumber(2)))
  }

  test("simple merge") {
    val t = run("(1,,true)")
    assertEquals(t, Some(IMergeValue(INumber(1), IBool(true))))
  }

  test("projection of simple merge") {
    val t = run("(1,,true) : int")
    assertEquals(t, Some(INumber(1)))
  }

  test("projection to unknown of simple merge") {
    val t = run("(1,,true) : * : int")
    assertEquals(t, Some(INumber(1)))
  }

  test("paper section 2.2: Introducing the merge operator") {
    val t = run("let x = 1,,true in (x+1, ¬x)")
    assertEquals(t.map(_.pprint), Some("<2, false>"))
  }
  test(
    "Paper Section 2.2. Type-directed Semantics of Merges and the Interaction with Subtyping"
  ) {
    val t = run("let x = 1,,true in (x+1, ¬x)")
    assertEquals(t.map(_.pprint), Some("<2, false>"))
  }

  test("Paper Section 2.2. Disjoint Intersection Types") {
    val t = run("((λx.((x,,1)+1)):bool -> int) (true,,2)")
    assertEquals(t.map(_.pprint), Some("2"))
  }
  test("Paper Section 2.3. Circle mixin part 1/2") {
    val t = run(
      "let pi = 3 in\n" +
        "let circle = (λsuper. super,, {area = (λradius. pi * radius * radius) : int -> int}) in\n" +
        "let c = circle({perimeter = (λradius. 2 * pi * radius) : int -> int}) in\n" +
        "(c.area(10), c.perimeter(10))"
    )
    assertEquals(t.map(_.pprint), Some("<(300 : *), (60 : *)>"))
  }
  test("Paper Section 2.3. Circle mixin part 2/2") {
    val t = run(
      "let pi = 3 in\n" +
        "let circle = (λsuper. super,, {area = (λradius. pi * radius * radius): int -> int}) in\n" +
        "let c = circle({area = (λradius. 2 * pi * radius) : int -> int}) in\n" +
        "(c.area(10), c.perimeter(10))"
    )
    assertEquals(t.map(_.pprint), None)
  }
  test("Paper section 2.4. Cast combination strategy") {
    val t = run(
      "(λx. (x ,, true)) : int -> int & bool : int -> (int & T) : int -> int"
    )
    assertEquals(
      t.map(_.pprint),
      Some(
        "((((λx. (x,, true)) : int -> (int & bool)) : int -> (int & T)) : int -> int)"
      )
    )
  }
  test("Paper section 2.4. Ambiguity Errors and Type Errors part 1/3") {
    val t = run("(1 : ★,, 2 : ★) : int")
    assertEquals(t, None)
  }
  test("Paper section 2.4. Ambiguity Errors and Type Errors part 2/3") {
    val t = run("(true : ★,, 1 : ★) : int")
    assertEquals(t.map(_.pprint), Some("1"))
  }
  test("Paper section 2.4. Ambiguity Errors and Type Errors part 3/3") {
    val t = run("((1 : ★,, 2 : ★) : ★,,3 : ★) : int")
    assertEquals(t, None)
  }
  test("Paper section 2.4. Encoding the GTFL Calculus part 1/3") {
    val t = run("(({l1 = 1},, {l2 = true}) : {l1 : int} & {l2 : bool}).l2")
    assertEquals(t.map(_.pprint), Some("true"))
  }
  test("Paper section 2.4. Encoding the GTFL Calculus part 2/3") {
    val t = run("(({l1 = 1},, {l2 = true}) : {l1 : int} & ★).l2")
    assertEquals(t.map(_.pprint), Some("(true : *)"))
  }

  test("untyped lambda in infer position") {
    val t = run("(λx.x) 1")
    assertEquals(t.map(_.pprint), Some("(1 : *)"))
  }
  test("typed lambda applied to 1") {
    val t = run("(λx.x) : * 1")
    assertEquals(t.map(_.pprint), Some("(1 : *)"))
  }
  test("untyped nested lambda in infer position") {
    val t = run("(λx.(λy.y)) : * -> * 1")
    assertEquals(t.map(_.pprint), Some("(((λy. y) : * -> *) : *)"))
    assertEquals(
      run("((λx.(λy.y)) : * -> * 1) 1").map(_.pprint),
      Some("(1 : *)")
    )
  }

  test("Paper section 2.4. Encoding the GTFL Calculus part 3/3") {
    val t = run(
      "let f = (λx. λy. x ,, y) in\n" +
        "(f {l1 = 1}) {l1 = 2}"
    )
    assertEquals(
      t.map(_.pprint),
      Some("((({l1 = (1 : *)} : *), ({l1 = (2 : *)} : *)) : *)")
    )
  }

  test("Paper section 2.4. Modular Type-based Invariants") {
    val t = run(
      "(({l1 = 5},, {l2 = true}) : ★ : {l1: int} : ★ : {l1: int} & {l2: bool}).l2"
    )
    assertEquals(t.map(_.pprint), None)
  }
  test("Paper section 2.4. Counterexample of the DGG part 1/2") {
    val t = run("((1,,true):int,, (2,,false):bool) : int")
    assertEquals(t.map(_.pprint), Some("1"))
  }
  test("Paper section 2.4. Counterexample of the DGG part 2/2") {
    val t = run("((1,,true):★,, (2,,false):★) : int")
    assertEquals(t.map(_.pprint), None)
  }

  test("simple fix") {
    val t =
      run("(fix f. (λx. if x == 0 then 1 else x * f (x - 1))) : int -> int 5")
    assertEquals(t.map(_.pprint), Some("120"))
  }

  test("unit") {
    val t = run("let x = () in x")
    assertEquals(t.map(_.pprint), Some("()"))
  }

  test("class encoding") {
    val t = run(
      "let class = (λx. fix self. ({foo = (λx. self.bar): int -> int},,{bar = 2}) : {foo: int -> int} & {bar: int}) : unit -> {foo: int -> int} & {bar: int} in\n" +
        "let obj = class () in\n" +
        "obj.foo 1"
    )
    assertEquals(t.map(_.pprint), Some("2"))
  }

}
