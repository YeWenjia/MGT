package glang

import glang.syntax._
import glang.syntax.Syntax._

import scala.util.parsing.combinator._
import scala.util.parsing.combinator.syntactical.StandardTokenParsers

class ExprParser
    extends StandardTokenParsers
    with PackratParsers
    with ImplicitConversions {

  lexical.reserved += ("if", "then", "else", "true", "false", "let", "in", "unit", "int", "string", "bool", "unit", "fst", "snd", "inl", "inr", "case", "as", "of", "∞", "Top", "T", "fix", "()")
  lexical.delimiters ++= (s": . <  > -> => + - * ★ * & / ( ) [ ] { } = ; , ,, ${symbols
    .map { _.parser }
    .mkString(" ")} :: : ? ⋆ T" split ' ')

}

class GExprParser extends ExprParser {
  override def log[T](p: => Parser[T])(name: String): Parser[T] = Parser { in =>
    //println("trying "+ name +" at "+ in)
    val r = p(in)
    //println(name +" --> "+ r)

    r
  }

  lazy val intType: PackratParser[IntType] = """int""" ^^ { _ => IntType() }
  lazy val boolType: PackratParser[BoolType] = """bool""" ^^ { _ => BoolType() }
  lazy val unitType: PackratParser[UnitType] = """unit""" ^^ { _ => UnitType() }
  lazy val topType: PackratParser[TopType] = """T""" ^^ { _ => TopType() }
  lazy val funcType: PackratParser[FuncType] = tpe ~ ("->" ~> tpe) ^^ {
    case t1 ~ t2 => FuncType(t1, t2)
  }
  lazy val recordType: PackratParser[RecordType] =
    (("{" ~> ident) <~ ":") ~ (tpe <~ "}") ^^ { case l ~ t => RecordType(l, t) }
  lazy val pairType: PackratParser[PairType] = tpe ~ ("x" ~> tpe) ^^ {
    case t1 ~ t2 => PairType(t1, t2)
  }
  lazy val intersectionType: PackratParser[IntersectionType] =
    tpe ~ ("&" ~> tpe) ^^ { case t1 ~ t2 => IntersectionType(t1, t2) }
  lazy val sumType: PackratParser[SumType] = tpe ~ ("+" ~> tpe) ^^ {
    case t1 ~ t2 => SumType(t1, t2)
  }
  lazy val unkType: PackratParser[Unknown] = "★" ^^ { _ => Unknown() }
  lazy val unkTypeAlt: PackratParser[Unknown] = "*" ^^ { _ => Unknown() }

  lazy val btpe: PackratParser[GType] =
    log(pairType)("pairType") | log(sumType)("sumType") | log(intersectionType)(
      "intersectionType"
    ) | log(funcType)("funcType") | recordType | log(intType)("intType") | log(
      boolType
    )("boolType") | unkType | unkTypeAlt | unitType | topType

  lazy val tpe: PackratParser[GType] =
    log(btpe)("btpe") | "(" ~> log(tpe)("parent") <~ ")"

  lazy val term: PackratParser[Term] = fix | asc | log(app)("app") | log(merge)(
    "merge"
  ) | record | pair | boolBinOp | boolUnOp | intIntBoolBinOp | intIntIntBinOp | proj | fst | snd | inj1 | inj2 | ite | let | caseE | bterm
  lazy val bterm: PackratParser[Term] = log(lambda)(
    "lambda"
  ) ||| unit ||| boolean ||| number ||| variable ||| top ||| parens //||| dyn

  lazy val number: PackratParser[Number] = numericLit ^^ { s =>
    Number(s.toInt)
  }
  lazy val unit: PackratParser[UnitVal] = "(" ~ ")" ^^ { s => UnitVal() }

  lazy val boolean: PackratParser[Bool] = ("true" | "false") ^^ { s =>
    Bool(s == "true")
  }

  lazy val record: PackratParser[Record] =
    (("{" ~> ident) <~ "=") ~ (term <~ "}") ^^ { case l ~ e => Record(l, e) }
  lazy val top: PackratParser[Top] = ("{" ~ "}") ^^ { case l ~ e => Top() }
  lazy val proj: PackratParser[Proj] = term ~ ("." ~> ident) ^^ { case e ~ l =>
    Proj(e, l)
  }

  lazy val lambda: PackratParser[Lambda] =
    lambdaS.parser ~> variable ~ ("." ~> term) ^^ { case x ~ e => Lambda(x, e) }
  //lazy val lambdaSimpl: PackratParser[Lambda] = lambdaS.parser ~> variable ~ (":" ~> tpe).?  ~ ("." ~> term) ^^ { case x ~ t ~ e  => Lambda(x, t.getOrElse(FuncType(Unknown(), Unknown())), e, t.isDefined) }

  lazy val asc: PackratParser[Asc] = term ~ (":" ~> tpe) ^^ { case e ~ t =>
    Asc(e, t)
  }
  //lazy val asc: PackratParser[Asc] = term ~ (":" ~> tpe) ^^ { case e ~ t => Asc(e, t) }

  lazy val variable: PackratParser[Var] = log(ident)("ident") ^^ { case p =>
    Var(p)
  }

  lazy val boolBinOpS: PackratParser[String] = (andS.parser | orS.parser) ^^ {
    case s => s
  }

  lazy val boolBinOp: PackratParser[BoolOp] = term ~ boolBinOpS ~ term ^^ {
    case t1 ~ boolOp ~ t2 => BoolOp(t1, t2, boolOp)
  }

  lazy val boolUnOpS: PackratParser[String] = (notS.parser) ^^ { case s => s }

  lazy val boolUnOp: PackratParser[BoolUnOp] = boolUnOpS ~ term ^^ {
    case boolOp ~ t1 => BoolUnOp(t1, boolOp)
  }

  lazy val intBoolOp: PackratParser[String] =
    (ltS.parser | gtS.parser | eqS.parser) ^^ { case s => s }

  lazy val intIntOp: PackratParser[String] =
    (timesS.parser | minusS.parser | plusS.parser) ^^ { case s => s }

  lazy val intIntBoolBinOp: PackratParser[IntIntBoolOp] =
    log(term ~ intBoolOp ~ term)("intIntBoolBinOp") ^^ { case t1 ~ intOp ~ t2 =>
      IntIntBoolOp(t1, t2, intOp)
    }

  lazy val intIntIntBinOp: PackratParser[IntIntIntOp] =
    log(term ~ intIntOp ~ term)("intIntIntBinOp") ^^ { case t1 ~ intOp ~ t2 =>
      IntIntIntOp(t1, t2, intOp)
    }

  lazy val innerPair: PackratParser[(Term, Term)] = term ~ "," ~ term ^^ {
    case t1 ~ comma ~ t2 => (t1, t2)
  }

  lazy val pair: PackratParser[GPair] =
    log(("(" ~> innerPair <~ ")"))("pair") ^^ { case p => GPair(p._1, p._2) }

  lazy val merge: PackratParser[Merge] = (term <~ ",,") ~ term ^^ {
    case t1 ~ t2 => Merge(t1, t2)
  }

  lazy val ite: PackratParser[Ite] =
    "if" ~ term ~ "then" ~ term ~ "else" ~ term ^^ {
      case "if" ~ t1 ~ "then" ~ t2 ~ "else" ~ t3 => Ite(t1, t2, t3)
    }

  lazy val parens: PackratParser[Term] = "(" ~> term <~ ")"

  //lazy val dyn: PackratParser[Term] = "{"~> term <~"}" ^^ { case t => dynify(t) }

  lazy val let: PackratParser[Let] =
    "let" ~ variable ~ "=" ~ term ~ "in" ~ term ^^ {
      case "let" ~ x ~ "=" ~ t2 ~ "in" ~ t1 => Let(x, t2, t1)
    }

  lazy val caseE: PackratParser[Case] =
    ("case" ~> term <~ "of") ~ ("{" ~> variable) ~ ("=>" ~> term <~ "}") ~ ("{" ~> variable) ~ ("=>" ~> term <~ "}") ^^ {
      case t ~ x1 ~ t1 ~ x2 ~ t2 => Case(t, x1, t1, x2, t2)
    }

  lazy val fix: PackratParser[Fix] = ("fix" ~> variable) ~ ("." ~> term) ^^ {
    case x ~ t => Fix(x, t)
  }

  lazy val app: PackratParser[App] = log(term)("t1") ~ log(term)("t2") ^^ {
    case t1 ~ t2 => App(t1, t2)
  }

  lazy val fst: PackratParser[First] = log("fst" ~> term)("fst") ^^ { case t =>
    First(t)
  }

  lazy val snd: PackratParser[Second] = "snd" ~> term ^^ { case t => Second(t) }

  lazy val inj1: PackratParser[Inj1] =
    ("inl" ~> ("{" ~> tpe <~ "}") ~ term) ^^ { case t ~ e => Inj1(e, t) }

  lazy val inj2: PackratParser[Inj2] =
    ("inr" ~> ("{" ~> tpe <~ "}") ~ term) ^^ { case t ~ e => Inj2(e, t) }

}
object Parser extends GExprParser {
  def parse(prog: String): Either[String, Term] =
    phrase(term)(new lexical.Scanner(prog)) match {
      case x: NoSuccess          => Left("[" + x.next.pos + "] failure: " + x.msg)
      case Success(result, next) => Right(result)
    }
}
