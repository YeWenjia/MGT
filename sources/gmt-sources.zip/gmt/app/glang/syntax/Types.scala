package glang.syntax
import Syntax._

/** Trait for general types extending the Type trait.
  */
trait GType extends Type {

  /** Method to check if a type is fully-precise.
    *
    * @return true if the type is static, false otherwise.
    */
  def static: Boolean = this match {
    case _: IntType               => true
    case _: BoolType              => true
    case _: UnitType              => true
    case FuncType(t1, t2)         => t1.static && t2.static
    case IntersectionType(t1, t2) => t1.static && t2.static
    case RecordType(l, t)         => t.static
    case SumType(t1, t2)          => t1.static && t2.static
    case PairType(t1, t2)         => t1.static && t2.static
    case TopType()                => true
    case BotType()                => true
    case _                        => false
  }

  /** Subtype checking method.
    *
    * @param t2 The type to check against.
    * @return true if this type is a subtype of t2, false otherwise.
    */
  def <=(t2: GType): Boolean = {
    (this, t2) match {
      case (HoleType(), _)            => true
      case (_, HoleType())            => true
      case (a, TopType()) if a.static => true
      case (Unknown(), Unknown())     => true
      case (IntType(), IntType())     => true
      case (BoolType(), BoolType())   => true
      case (UnitType(), UnitType())   => true
      case (FuncType(t11, t12), FuncType(t21, t22)) => {
        (t21 <= t11) && (t12 <= t22)
      }
      case (RecordType(l1, t1), RecordType(l2, t2)) => {
        (l1 == l2) && (t1 <= t2)
      }
      case (SumType(t11, t12), SumType(t21, t22)) => {
        (t11 <= t21) && (t12 <= t22)
      }
      case (PairType(t11, t12), PairType(t21, t22)) => {
        (t11 <= t21) && (t12 <= t22)
      }

      case (t1, IntersectionType(t2, t3)) => {
        (t1 <= t2) && (t1 <= t3)
      }

      case (IntersectionType(t1, t2), t3) => {
        (t1 <= t3) || (t2 <= t3)
      }

      case (BotType(), _) => true

      case _ => false
    }
  }

  /** Consistent Subtype checking method.
    *
    * @param t2 The type to check against.
    * @return true if this type is consistent subtype of t2, false otherwise.
    */
  def <~(t2: GType): Boolean = {
    (this, t2) match {
      case (HoleType(), _) => true
      case (_, HoleType()) => true
      case (Unknown(), _)  => true //CS-DYNL
      case (_, Unknown())  => true // CS-DYNR
      case (BotType(), _)  => true // CS-BOT
      case (_, TopType())  => true // CS-BOT

      case (FuncType(t11, t12), FuncType(t21, t22)) => {
        (t21 <~ t11) && (t12 <~ t22)
      } // CS-ARR

      case (t1, IntersectionType(t2, t3)) => {
        (t1 <~ t2) && (t1 <~ t3)
      }

      case (IntersectionType(t1, t2), t3) => {
        (t1 <~ t3) || (t2 <~ t3)
      }

      case (RecordType(l1, t1), RecordType(l2, t2)) if l1 == l2 => t1 <~ t2

      case (SumType(t11, t12), SumType(t21, t22)) =>
        (t11 <~ t21) && (t12 <~ t22)
      case (PairType(t11, t12), PairType(t21, t22)) =>
        (t11 <~ t21) && (t12 <~ t22)

      case _ => this == t2
    }
  }

  /** Method to check if two types are disjoint.
    *
    * @param t2 The type to check against.
    * @return true if the types are disjoint, false otherwise.
    */
  def *(t2: GType): Boolean = !(this ∩ t2)

  /** Method to check if two types are joinable.
    *
    * @param t2 The type to check against.
    * @return true if the types are joinable, false otherwise.
    */
  def ∩(t2: GType): Boolean = {
    (this, t2) match {

      case (BotType(), _: Ordinary)         => true
      case (_: Ordinary, BotType())         => true
      case (FuncType(_, _), FuncType(_, _)) => true

      case (RecordType(l1, t1), RecordType(l2, t2)) if l1 == l2 => true

      case (IntersectionType(t1, t2), t3) => (t1 ∩ t3) || (t2 ∩ t3)
      case (t1, IntersectionType(t2, t3)) => (t1 ∩ t2) || (t1 ∩ t3)

      case (SumType(t11, t12), SumType(t21, t22)) =>
        (t11 ∩ t21) && (t12 ∩ t22)
      case (PairType(t11, t12), PairType(t21, t22)) =>
        (t11 ∩ t21) && (t12 ∩ t22)

      case (IntType(), IntType())   => true
      case (BoolType(), BoolType()) => true
      case (UnitType(), UnitType()) => true
      case (BotType(), BotType())   => true
      case _                        => this == false
    }
  }

  /** Method to compute the corresponding ground type of a type.
    * A ground type is the most imprecise top-level constructor of a type.
    *
    * @return The ground type of the type.
    */
  def ground: GType = this match {
    case FuncType(t1, t2)         => FuncType(Unknown(), Unknown())
    case SumType(t1, t2)          => SumType(Unknown(), Unknown())
    case PairType(t1, t2)         => PairType(Unknown(), Unknown())
    case IntersectionType(t1, t2) => IntersectionType(Unknown(), Unknown())
    case RecordType(l, t)         => RecordType(l, Unknown())
    case _                        => this
  }

  /** Method to check if a type is a ground type.
    *
    * @return true if the type is a ground type, false otherwise.
    */
  def isGround: Boolean = this.ground == this

  /** Method to add parenthesis to types for printing purposes.
    *
    * @param t The type to add parenthesis to.
    * @param f The function to apply to the type.
    * @return The type with parenthesis added.
    */
  def parentify(t: GType, f: GType => String) = t match {
    case _: FuncType         => "(" + f(t) + ")"
    case _: SumType          => "(" + f(t) + ")"
    case _: PairType         => "(" + f(t) + ")"
    case _: IntersectionType => "(" + f(t) + ")"
    case _                   => f(t)
  }

  /** Method to check if two types are equal.
    * This is used during type checking where consistent subtyping is only used by the subsumption rule (TYP-SUB)
    * Every other location use the equality relation.
    * @param t2 The type to check against.
    * @return true if the types are equal, false otherwise.
    */
  def eq(t2: GType): Boolean = {
    (this, t2) match {
      case (HoleType(), _) => true
      case (_, HoleType()) => true
      case _               => this == t2
    }
  }
}

object GTypes {

  /** helper functions over types */

  /** Method to compute the codomain of a function type.
    *
    * @param t The type to compute the codomain of.
    * @return The codomain of the function type.
    */
  def cod(t: Type): GType = t match {
    case FuncType(t1, t2) => t2
    case Unknown()        => Unknown()
    case HoleType()       => HoleType()
    case _ =>
      throw new TypeError("Error: \\(" + t.toLatex + "\\) is not a function")
  }

  /** Method to compute the domain of a function type.
    *
    * @param t The type to compute the domain of.
    * @return The domain of the function type.
    */
  def dom(t: Type): GType = t match {
    case FuncType(t1, t2) => t1
    case Unknown()        => Unknown()
    case HoleType()       => HoleType()
    case _ =>
      throw new TypeError("Error: \\(" + t.toLatex + "\\) is not a function")
  }

  /** Method to check if a label is in a record type.
    *
    * @param l The label to check for.
    * @param t The type to check.
    * @return true if the label is in the record type, false otherwise.
    */
  def ∈(l: String, t: Type): Boolean = t match {
    case RecordType(l1, _)      => l == l1
    case IntersectionType(a, b) => ∈(l, a) || ∈(l, b)
    case _                      => false
  }

  /** Method to project a label from a record type.
    *
    * @param l The label to project.
    * @param t The type to project from.
    * @return The type of the label.
    */
  def proj(l: String, t: GType): GType = t match {
    case RecordType(l1, t1) if (l == l1)                   => t1
    case a if (a <= Unknown()) && !(∈(l, a))               => Unknown()
    case HoleType()                                        => HoleType()
    case IntersectionType(a, b) if !(∈(l, b)) && (∈(l, a)) => proj(l, a)
    case IntersectionType(a, b) if !(∈(l, a)) && (∈(l, b)) => proj(l, b)
    case _ =>
      throw new TypeError("Error: \\(" + t.toLatex + "\\) is not a record")
  }

  /** Method to project the first component of a pair type.
    *
    * @param t The type to project from.
    * @return The first component of the pair type.
    */
  def pi1(t: Type): GType = t match {
    case PairType(t1, t2) => t1
    case Unknown()        => Unknown()
    case HoleType()       => HoleType()
    case _                => throw new TypeError("Wrong type for pi1 " + t)
  }

  /** Method to project the second component of a pair type.
    *
    * @param t The type to project from.
    * @return The second component of the pair type.
    */
  def pi2(t: Type): GType = t match {
    case PairType(t1, t2) => t2
    case Unknown()        => Unknown()
    case HoleType()       => HoleType()
    case _                => throw new TypeError("Wrong type for pi1 " + t)
  }

  /** Method to project the first component of a sum type.
    *
    * @param t The type to project from.
    * @return The first component of the sum type.
    */
  def pis1(t: Type): GType = t match {
    case SumType(t1, t2) => t1
    case Unknown()       => Unknown()
    case HoleType()      => HoleType()
    case _               => throw new TypeError("Wrong type for pis1 " + t)
  }

  /** Method to project the second component of a sum type.
    *
    * @param t The type to project from.
    * @return The second component of the sum type.
    */
  def pis2(t: Type): GType = t match {
    case SumType(t1, t2) => t2
    case Unknown()       => Unknown()
    case HoleType()      => HoleType()
    case _               => throw new TypeError("Wrong type for pis1 " + t)
  }

}

/** class to represent a type that is the bottom of the lattice
  * A bot type is a simple type and is not unknown
  */
case class BotType() extends GType with SimpleType with NotUnk {
  def pprint = "Bot"

  def toLatex = "\\bot"
}

/** Case class representing a type that is the top of the lattice.
  * A top type is a simple type and is not unknown
  */
case class TopType() extends GType with SimpleType with NotUnk {
  def pprint = "T"

  def toLatex = "\\top"
}

/** Case class representing an integer type.
  * An int type is a simple type and is not unknown
  */
case class IntType() extends GType with SimpleType with NotUnk with Ordinary {
  def pprint = "int"

  def toLatex = "\\Int"

}

/** Case class representing a boolean type.
  * A bool type is a simple type and is not unknown
  */
case class BoolType() extends GType with SimpleType with NotUnk with Ordinary {
  def pprint = "bool"

  def toLatex = "\\Bool"

}

/** Case class representing an unknown type.
  */
case class Unknown() extends GType {
  def pprint = "*"

  def toLatex = "\\star"

}

/** Case class representing a unit type.
  * A unit type is a simple type and is not unknown
  */
case class UnitType() extends GType with SimpleType with NotUnk with Ordinary {
  def pprint = "Unit"

  def toLatex = "\\Unit"
}

/** Class to represent a hole in a type.
  * It is used to type Hole Terms.
  */
case class HoleType() extends GType with NotUnk {
  def pprint = "[]"

  def toLatex = "[]"

}

/** Case class representing a function type.
  * We use parentify to add parenthesis to the function type.
  *
  * @param t1 The domain of the function.
  * @param t2 The codomain of the function.
  */
case class FuncType(t1: GType, t2: GType)
    extends GType
    with NotUnk
    with Ordinary {

  def pprint = t1.pprint + " -> " + parentify(t2, _.pprint)

  def toLatex = s"\\functype{${t1.toLatex}}{${t2.toLatex}}"

}

/** Case class representing a sum type.
  * We use parentify to add parenthesis to the sum type.
  *
  * @param t1 The first type in the sum.
  * @param t2 The second type in the sum.
  */
case class SumType(t1: GType, t2: GType)
    extends GType
    with NotUnk
    with Ordinary {

  def pprint = parentify(t1, _.pprint) + " + " + parentify(t2, _.pprint)

  def toLatex = parentify(t1, _.toLatex) + s" + " + parentify(t2, _.toLatex)
}

/** Case class representing a pair type.
  * We use parentify to add parenthesis to the pair type.
  *
  * @param t1 The first type in the pair.
  * @param t2 The second type in the pair.
  */
case class PairType(t1: GType, t2: GType)
    extends GType
    with NotUnk
    with Ordinary {

  def pprint = parentify(t1, _.pprint) + " x " + parentify(t2, _.pprint)

  def toLatex =
    parentify(t1, _.toLatex) + s" \\times  " + parentify(t2, _.toLatex)

}

/** Case class representing an intersection type.
  * We use parentify to add parenthesis to the intersection type.
  *
  * @param t1 The first type in the intersection.
  * @param t2 The second type in the intersection.
  */
case class IntersectionType(t1: GType, t2: GType) extends GType with NotUnk {

  def pprint = parentify(t1, _.pprint) + " & " + parentify(t2, _.pprint)

  def toLatex = parentify(t1, _.toLatex) + s" \\& " + parentify(t2, _.toLatex)

}

/** Case class representing a record type.
  *
  * @param l The label of the record.
  * @param t The type of the record.
  */
case class RecordType(l: String, t: GType)
    extends GType
    with NotUnk
    with Ordinary {
  def pprint = s"{${l}: ${t.pprint}}"

  def toLatex = s"\\{\\mathit{${l}}: ${t.toLatex}\\}"

}

case class TypeEnvironment(m: Map[Var, GType] = Map()) {
  def lookup(x: Var) = m.find(_._1.x == x.x).map(_._2)

  def extend(x: Var, t: GType): TypeEnvironment = new TypeEnvironment(
    m + (x -> t)
  )

  def extend(t: Tuple2[Var, GType]): TypeEnvironment = new TypeEnvironment(
    m + t
  )
}

case class Environments(te: TypeEnvironment = TypeEnvironment()) {
  def extend(x: Var, t: GType) = this.copy(te = this.te.extend(x, t))

  def extend(vars: Tuple2[Var, GType]) = this.copy(te = this.te.extend(vars))
}

object TypeEnvironment {
  def apply(vars: Tuple2[Var, GType]*) = new TypeEnvironment(vars.toMap)
}
