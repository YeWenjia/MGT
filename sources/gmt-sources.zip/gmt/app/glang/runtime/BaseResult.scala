package glang.runtime

import glang.syntax.Syntax.Term
import glang.typing.IConfLatex

/** This trait represents a result of a reduction. It contains the result of the reduction, the configurations
  * of the reduction, the step where the reduction stopped and a flag indicating if the reduction is finished.
  */
trait BaseResult {
  val r: Either[Term, IRuntimeException]
  val configurations: List[IConfLatex]
  val step: Int
  val finished: Boolean
}
