package glang.runtime

import glang.syntax
import glang.syntax.Syntax._
import glang.typing._

import scala.annotation.tailrec
import scala.collection.immutable.ListMap
import glang.syntax.GTypes._
import glang.syntax._
import glang.typing.TypeDerivation._

/** This class represents a runtime exception * */
class IRuntimeException(val s: String) extends Exception(s) with IResult

/** this object defines the different substitution models you can adopt. In this implementation we
  * explicit substitution but you can support both models
  */
object SubstitutionModel extends Enumeration {
  type SubstitutionModel = Value
  val Explicit, Implicit = Value
}

object Runtime {
  import SubstitutionModel._

  /** The type of the RuntimeEnvironment.
    * Adapt this to any kind of environment you want to track during runtime.
    * For instance, now is used to support implicit substitutions.
    */
  type RuntimeEnvironment = Env[IVar]

  /** This class represents a frame of the reduction stack */
  case class IContext(t: TypeDerivation, env: RuntimeEnvironment) {
    def pprint = {
      t.pprint + "  |   " + env.pprint

    }
  }
  type Frame = IContext
  type Frames = List[Frame]

  /** This class represents a result of a reduction. It contains the result of the reduction, the configurations
    * of the reduction, the step where the reduction stopped and a flag indicating if the reduction is finished.
    */
  case class Result(
      r: Either[TypeDerivation, IRuntimeException],
      configurations: List[IConfLatex],
      step: Int = 0,
      finished: Boolean = true
  ) extends BaseResult
  case class Configuration(c: IContext, lenv: LinearEnv)

  /** Main class of reduction. This is the one in charge of reducing a type derivation
    * @param t The type derivation to reduce
    * @param env The lexical environment to use during reduction
    * @param lenv The linear environment to use during reduction
    * @param fromStep The step where the reduction starts (this in the case of many steps that may bloat the interface)
    * @param stepSize The number of single steps to take
    * @param substitutionMode The substitution model to use
    * @param o The options to use during reduction
    */
  case class Reducer(
      t: TypeDerivation,
      env: RuntimeEnvironment = new RuntimeEnvironment(),
      lenv: LinearEnv = new LinearEnv(),
      fromStep: Int = 0,
      stepSize: Int = 20
  )(implicit
      substitutionMode: SubstitutionModel = Explicit,
      o: IOptions = IOptions()
  ) extends BaseReducer[Result] {

    /** the current step number */
    var nstep: Int = 0

    /** the list of type derivations and environments reduced so far */
    var configurations: List[IConfLatex] = Nil

    /** the current type derivation and environments */
    var current: Configuration = Configuration(IContext(t, env), lenv)

    def reduce: Result = {

      /** Initially the frame is just the complete type derivation and an empty environment */
      val c = List(IContext(t, env))

      /** The first configuration is the initial one. We compute the latex representation of the type
        * derivatio tree to use it in the interface
        */
      configurations = List(
        IConfLatex(
          reconstructITerm(c).getLatexDerivationTree,
          env.toLatex,
          lenv.toLatex
        )
      )

      /** this is the call to the recursive function */
      reduce(c, lenv).step
    }

    /** This is the main function of the reduction. It takes a list of frames and a linear environment and reduces the
      * type derivation. Contrary to typing here we only make use of one stack.
      * It returns a trampoline to stop reduction after a step, export to latex the current step,
      * and continue with the reduction. We also check if the number of steps have been reached and if so we stop.
      * @param c The current list of frames to reduce
      * @param lenv The current linear environment
      * @param substitutionMode The substitution model to use (here we are using explicit substitution, i.e. we are not
      *                         using this paramter)
      * @return A trampoline to continue the reduction
      */
    def reduce(c: Frames, lenv: LinearEnv)(implicit
        substitutionMode: SubstitutionModel
    ): Trampoline = {

      c match {

        /** Fix
          * IN: fix x. t : T, ...
          * OUT: t[fix x. t/x]: T, ...
          */
        case IContext(f @ IAsc(IFix(x, t, _), a), env) :: xs =>
          val newE = IAsc(subst(t, x, f), a)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          ) //Step-fix (1/2)

        /** IN: fix x. t, [] : T,...
          * OUT: t[(fix x. t) : T/x]:: T, ...
          */
        case IContext(f @ IFix(x, t, _), env2) :: IContext(
              IAsc(IHole(), a),
              env1
            ) :: xs =>
          val newE = IAsc(subst(t, x, IAsc(f, a)), a)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          ) //Step-fix (2/2)

        /** STEP-APP
          * IN: ((\x.t): T1 -> T2) t2, ...
          * OUT: ((\x. t) (t2: T1)) : T2,...
          */
        case IContext(
              IApp(IAscVal(l: ILambda, FuncType(a1, a2)), t2),
              env
            ) :: xs => { //Step-app (1/2)
          val newE = IAsc(IAppRT(l, IAsc(t2, a1)), a2)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }
        /** STEP-APP (part 2)
          * IN: (t1 <= _ : T1 -> T2) t2...
          * OUT: ((t1 (t2 : T1) <= T2) : T2
          */
        case IContext(
              IApp(IAscVal(Sub(t1, _), FuncType(a1, a2)), t2),
              env
            ) :: xs => { //Step-app (2/2)
          val newE = IAsc(Sub(IApp(t1, IAsc(t2, a1)), a2), a2)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }

        /** Ascriptions to unknown */
        /** Transforming a Ascription to a ValueAscription. Bureaucracy to know when to stop reducing
          * IN: (g <= _ : *), ...
          * OUT:  (g <= *:_v *), ...
          */
        case IContext(IAsc(SubValue(g: IValue, _), Unknown()), env) :: xs
            if isGround(g) => {
          val newE = IAscVal(SubValue(g, Unknown()), Unknown())
          More(() => reduce(IContext(newE, env) :: xs, lenv))
        }
        /** STEP-ABS
          * IN: (\x.t) : *, ...
          * OUT: (\x.t) : * -> * : *, ...
          */
        case IContext(IAsc(ILambda(x, t, ty), Unknown()), env) :: xs => { // STEP-ABS
          val newE = IAscVal(
            SubValue(
              IAscVal(
                ILambda(x, t, FuncType(Unknown(), Unknown())),
                FuncType(Unknown(), Unknown())
              ),
              Unknown()
            ),
            Unknown()
          )
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }

        /** records */
        /** Transforming a Record to a ValueRecord. Bureaucracy to know when to stop reducing
          * IN: {l = v'}, ...
          * OUT: {l = v'}_v, ...
          */
        case IContext(IRecord(l, v: IValue), env) :: xs => {
          val newE = IRecordValue(l, v)
          More(() => reduce(IContext(newE, env) :: xs, lenv))
        }

        /** Same as before but for projections
          * IN: v.l, ...
          * OUT: v._vl, ...
          */
        case IContext(IProj(v: IValue, l), env) :: xs => {
          val a = proj(l, v.tpe)
          cast(v, RecordType(l, a)) match {
            case IRecordValue(lp, vp) if l == lp =>
              val newE = vp
              Step(
                c,
                lenv,
                IContext(newE, env) :: xs,
                lenv,
                (s: Frames) => reduce(s, lenv),
                List(newE)
              )
            case e: IRuntimeException => IError(c, lenv, e, List())
          }
        }

        /** STEP-EVAL
          * IN: {l = s1}, ...
          * OUT: s1, {l = []}, ...
          */
        case IContext(IRecord(l, (s1: ISerious)), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IRecord(l, IHole()), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: s1.l, ...
          * OUT: s1, [].l, ...
          */
        case IContext(IProj((s1: ISerious), l), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IProj(IHole(), l), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, {l: []}, ...
          * OUT: {l: v}, ...
          */
        case IContext((v: SimpleValue), env1) :: IContext(
              IRecord(l, IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IRecord(l, v), env2) :: xs, lenv))
        /** STEP-EVAL
          * IN: v, [].l, ...
          * OUT: v.l, ...
          */
        case IContext((v: SimpleValue), env1) :: IContext(
              IProj(IHole(), l),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IProj(v, l), env2) :: xs, lenv))

        /** merges */
        /** IN: (v1,,v2), ...
          * OUT: (v1,,v2)_v, ...
          */
        case IContext(IMerge(v1: IValue, v2: IValue), env) :: xs =>
          val newE = IMergeValue(v1, v2)
          More(() => reduce(IContext(newE, env) :: xs, lenv))

        /** STEP-EVAL
          * IN: (v1,,s2), ...
          * OUT: s2, (v1,,[]), ...
          */
        case IContext(IMerge(v1: IValue, s2: ISerious), env) :: xs =>
          More(() =>
            reduce(
              IContext(s2, env) :: IContext(IMerge(v1, IHole()), env) :: xs,
              lenv
            )
          )
        /** STEP-EVAL
          * IN: (s1, s2), ...
          * OUT: s1, ([], s2), ...
          */
        case IContext(IMerge((s1: ISerious), s2: TypeDerivation), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IMerge(IHole(), s2), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, ([],,t2), ...
          * OUT: (v,,t2), ...
          */
        case IContext((v: IValue), env1) :: IContext(
              IMerge(IHole(), t2),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IMerge(v, t2), env2) :: xs, lenv))
        /** STEP-EVAL
          * IN: v, (v1,,[]), ...
          * OUT: (v1,,v), ...
          */
        case IContext((v: IValue), env1) :: IContext(
              IMerge(v1, IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IMerge(v1, v), env2) :: xs, lenv))

        /** If then else */
        /** IN: if true then t2 else t3, ...
          * OUT: t2, ...
          */
        case IContext(e @ IIte(SubValue((v: IBool), tpeAnn), t2, t3), env) :: xs
            if v == IBool(true) => {
          val newE = t2
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }

        /** IN: if false then t2 else t3, ...
          * OUT: t3, ...
          */
        case IContext(e @ IIte(SubValue((v: IBool), tpeAnn), t2, t3), env) :: xs
            if v == IBool(false) => {
          val newE = t3
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }
        /** IN: if s then t2 else t3, ...
          * OUT: s, if [] then t2 else t3, ...
          */
        case IContext(IIte(s: ICheckedSerious, t2, t3), env) :: xs =>
          More(() =>
            reduce(
              IContext(s, env) :: IContext(IIte(IHole(), t2, t3), env) :: xs,
              lenv
            )
          )

        /** IN: v, if [] then t2 else t3, ...
          * OUT: if v then t2 else t3, ...
          */
        case IContext(v1: ICheckedValue, env1) :: IContext(
              IIte(IHole(), t1, t2),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IIte(v1, t1, t2), env2) :: xs, lenv))

        /** SUB */
        /** IN: v <= ty, ...
          * OUT: v <=_v ty, ...
          */
        case IContext(Sub(e: IValue, ty), env) :: xs =>
          More(() => reduce(IContext(SubValue(e, ty), env) :: xs, lenv))

        /** STEP-EVAL
          * IN: v <= ty, [] <= ty, ...
          * OUT: v <= ty, ...
          */
        case IContext(v1: IValue, _) :: IContext(Sub(IHole(), ty), env) :: xs =>
          More(() => reduce(IContext(SubValue(v1, ty), env) :: xs, lenv))

        /** STEP-EVAL
          * IN: s <= ty, ...
          * OUT: s, [] <= ty, ...
          */
        case IContext(Sub(e: ISerious, ty), env) :: xs =>
          More(() =>
            reduce(
              IContext(e, env) :: IContext(Sub(IHole(), ty), env) :: xs,
              lenv
            )
          )

        /** APP */
        /** STEP-APP
          * IN: (v <= _ : T1 -> T2) v2, ...
          * OUT: (v (v2 : T1) <= T1) <= T2 : T2, ...
          */
        case IContext(
              app @ IApp(
                IAscVal(SubValue(v: IValue, _), FuncType(a1, a2)),
                v2 @ SubValue(_: IValue, _)
              ),
              env
            ) :: xs => { //STEP-APP
          val newE = IAsc(Sub(IApp(v, Sub(IAsc(v2, a1), dom(v.tpe))), a2), a2)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }

        /** STEP-DYN
          * IN: (g <= * : *) v2, ...
          * OUT: ((g <= * : *) <= * -> * : * -> *) v2
          */
        case IContext(
              app @ IApp(
                v1 @ IAscVal(SubValue(g: IValue, _), Unknown()),
                v2 @ SubValue(_: IValue, _)
              ),
              env
            ) :: xs => { //STEP-DYN
          val newE = IApp(
            IAsc(
              Sub(v1, FuncType(Unknown(), Unknown())),
              FuncType(Unknown(), Unknown())
            ),
            v2
          )
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }

        /** STEP-EVAL
          * IN: v1 c, ...
          * OUT: c, v1 [], ...
          */
        case IContext(IApp(v1: IValue, c: ICheckedSerious), env) :: xs =>
          More(() =>
            reduce(
              IContext(c, env) :: IContext(IApp(v1, IHole()), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: s1 s2, ...
          * OUT: s1, [] s2, ...
          */
        case IContext(IApp((s1: ISerious), s2: TypeDerivation), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IApp(IHole(), s2), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v1, [] s2, ...
          * OUT: v1 s2, ...
          */
        case IContext(v1: IValue, env1) :: IContext(
              IApp(IHole(), t2),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IApp(v1, t2), env2) :: xs, lenv))

        /** STEP-EVAL
          * IN: v2, v1 [], ...
          * OUT: v1 v2, ...
          */
        case IContext(v2: ICheckedValue, env1) :: IContext(
              IApp(v1, IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IApp(v1, v2), env2) :: xs, lenv))

        /** STEP-BETA
          * IN: (\x.t) v2, ...
          * OUT: t[v2/x], ...
          */
        case IContext(
              app @ IAppRT(ILambda(x, t, FuncType(a, b)), v2: IValue),
              env
            ) :: xs => { //STEP-BETA
          val newE = subst(t, x, v2)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newE)
          )
        }

        /** STEP-EVAL
          * IN: (\x.t) s2, ...
          * OUT: s2, (\x.t) [], ...
          */
        case IContext(IAppRT(v1: IValue, s2: ISerious), env) :: xs =>
          More(() =>
            reduce(
              IContext(s2, env) :: IContext(IAppRT(v1, IHole()), env) :: xs,
              lenv
            )
          )
        /** STEP-EVAL
          * IN: v2, (\x.t) [], ...
          * OUT: (\x.t) v2, ...
          */
        case IContext(v2: IValue, env1) :: IContext(
              IAppRT(v1, IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IAppRT(v1, v2: IValue), env2) :: xs, lenv))

        /** ASC */
        /** IN: (v : ty), ...
          * OUT: (v :_v ty), ...
          */
        case IContext(IAsc(v: ILambda, ty), env) :: xs =>
          More(() => reduce(IContext(IAscVal(v, ty), env) :: xs, lenv))
        case IContext(IAsc(SubValue(v: IValue, _), a), env) :: xs => {
          cast(v, a) match {
            case vp: IValue =>
              val newE = vp
              Step(
                c,
                lenv,
                IContext(newE, env) :: xs,
                lenv,
                (s: Frames) => reduce(s, lenv),
                List(newE)
              )
            case e: IRuntimeException => IError(c, lenv, e, List())
          }
        }

        /** STEP-EVAL
          * IN: (s1 : tp), ...
          * OUT: s1, ([] : tp), ...
          */
        case IContext(IAsc(s1: ICheckedSerious, tp), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IAsc(IHole(), tp), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, ([] : tp), ...
          * OUT: (v : tp), ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IAsc(IHole(), b),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IAsc(v, b), env2) :: xs, lenv))

        /** Let */
        /** IN: let x = v in t2, ...
          * OUT: t2[v/x], ...
          */
        case IContext(ILet(x, v: IValue, t2), env) :: xs => {
          val newE = subst(t2, x, v)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(t2)
          )
        }

        /** STEP-EVAL
          * IN: let x = s in t2, ...
          * OUT: s, let x = [] in t2, ...
          */
        case IContext(ILet(x, (s: ISerious), t2), env) :: xs =>
          More(() =>
            reduce(
              IContext(s, env) :: IContext(ILet(x, IHole(), t2), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, let x = [] in t2, ...
          * OUT: let x = v in t2, ...
          */
        case IContext(v: IValue, env1) :: IContext(
              ILet(x, IHole(), t2),
              env2
            ) :: xs =>
          More(() => reduce(IContext(ILet(x, v, t2), env2) :: xs, lenv))

        /** bool -> bool -> bool */
        /** IN: v1 <= _ op v2 <= _, ...
          * OUT: v1 [op] v2, ...
          */
        case IContext(
              IBoolOp(SubValue(v1: IValue, _), SubValue(v2: IValue, _), op),
              env
            ) :: xs => {
          cast(v1, BoolType()) match {
            case vp1: IBool => {
              cast(v2, BoolType()) match {
                case vp2: IBool => {
                  val v = op match {
                    case Syntax.andS.parser       => vp1.b && vp2.b
                    case syntax.Syntax.orS.parser => vp1.b || vp2.b
                  }
                  val newE = IBool(v)
                  Step(
                    c,
                    lenv,
                    IContext(newE, env) :: xs,
                    lenv,
                    (s: Frames) => reduce(s, lenv),
                    List(newE)
                  )
                }
                case e: IRuntimeException => IError(c, lenv, e, List())
              }
            }
            case e: IRuntimeException => IError(c, lenv, e, List())
          }
        }

        /** IN: v1 op s2, ...
          * OUT: s2, v1 op [], ...
          */
        case IContext(
              IBoolOp(v1: ICheckedValue, s2: ICheckedSerious, op),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s2, env) :: IContext(
                IBoolOp(v1, IHole(), op),
                env
              ) :: xs,
              lenv
            )
          )

        /** IN: s1 op s2, ...
          * OUT: s1, s1 op s2, ...
          */
        case IContext(
              IBoolOp(s1: ICheckedSerious, s2: TypeDerivation, op),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(
                IBoolOp(IHole(), s2, op),
                env
              ) :: xs,
              lenv
            )
          )

        /** IN: v, [] op t2, ...
          * OUT: v op t2, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IBoolOp(IHole(), t2, op),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IBoolOp(v, t2, op), env2) :: xs, lenv))

        /** IN: v, v1 op [], ...
          * OUT: v1 op v, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IBoolOp(v1, IHole(), op),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IBoolOp(v1, v, op), env2) :: xs, lenv))

        /** bool -> bool */
        /** IN: !v1, ...
          * OUT: [!] v1, ...
          */
        case IContext(IBoolUnOp(SubValue(v1: IValue, _), op), env) :: xs => {
          cast(v1, BoolType()) match {
            case vp1: IBool => {
              val v = op match {
                case syntax.Syntax.notS.parser => !vp1.b
              }
              val newE = IBool(v)
              Step(
                c,
                lenv,
                IContext(newE, env) :: xs,
                lenv,
                (s: Frames) => reduce(s, lenv),
                List(newE)
              )

            }
            case e: IRuntimeException => IError(c, lenv, e, List())
          }

        }

        /** IN: !s1, ...
          * OUT: s1, ![], ...
          */
        case IContext(IBoolUnOp(s1: ICheckedSerious, op), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IBoolUnOp(IHole(), op), env) :: xs,
              lenv
            )
          )

        /** IN: v, ![], ...
          * OUT: !v, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IBoolUnOp(IHole(), op),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IBoolUnOp(v, op), env2) :: xs, lenv))

        /** int -> int -> bool */
        /** IN: v1 <= _ op v2 <= _, ...
          * OUT: v1 [op] v2, ...
          */
        case IContext(
              e @ IIntIntBoolOp(
                SubValue((v1: IValue), _),
                SubValue((v2: IValue), _),
                op
              ),
              env
            ) :: xs => {
          cast(v1, IntType()) match {
            case vp1: INumber => {
              cast(v2, IntType()) match {
                case vp2: INumber => {
                  val v = op match {
                    case syntax.Syntax.ltS.parser => vp1.v < vp2.v
                    case syntax.Syntax.gtS.parser => vp1.v > vp2.v
                    case syntax.Syntax.eqS.parser => vp1.v == vp2.v
                  }
                  val newE = IBool(v)
                  Step(
                    c,
                    lenv,
                    IContext(newE, env) :: xs,
                    lenv,
                    (s: Frames) => reduce(s, lenv),
                    List(newE)
                  )
                }
                case e: IRuntimeException => IError(c, lenv, e, List())
              }
            }
            case e: IRuntimeException => IError(c, lenv, e, List())
          }
        }

        /** IN: v1 op s2, ...
          * OUT: s2, v1 op [], ...
          */
        case IContext(
              IIntIntBoolOp(v1: ICheckedValue, s2: ICheckedSerious, op),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s2, env) :: IContext(
                IIntIntBoolOp(v1, IHole(), op),
                env
              ) :: xs,
              lenv
            )
          )

        /** IN: s1 op s2, ...
          * OUT: s1, [] op s2, ...
          */
        case IContext(
              IIntIntBoolOp(s1: ICheckedSerious, s2: TypeDerivation, op),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(
                IIntIntBoolOp(IHole(), s2, op),
                env
              ) :: xs,
              lenv
            )
          )

        /** IN: v, [] op t2, ...
          * OUT: v op t2, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IIntIntBoolOp(IHole(), t2, op),
              env2
            ) :: xs =>
          More(() =>
            reduce(IContext(IIntIntBoolOp(v, t2, op), env2) :: xs, lenv)
          )

        /** IN: v, v1 op [], ...
          * OUT: v1 op v, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IIntIntBoolOp(v1, IHole(), op),
              env2
            ) :: xs =>
          More(() =>
            reduce(IContext(IIntIntBoolOp(v1, v, op), env2) :: xs, lenv)
          )

        /** int -> int -> int */
        /** IN: v1 <= _ op v2 <= _, ...
          * OUT: v1 [op] v2, ...
          */
        case IContext(
              e @ IIntIntIntOp(
                SubValue((v1: IValue), _),
                SubValue((v2: IValue), _),
                op
              ),
              env
            ) :: xs => {
          cast(v1, IntType()) match {
            case vp1: INumber => {
              cast(v2, IntType()) match {
                case vp2: INumber => {
                  val v = op match {
                    case syntax.Syntax.timesS.parser => vp1.v * vp2.v
                    case syntax.Syntax.minusS.parser => vp1.v - vp2.v
                    case syntax.Syntax.plusS.parser  => vp1.v + vp2.v
                  }
                  val newE = INumber(v)
                  Step(
                    c,
                    lenv,
                    IContext(newE, env) :: xs,
                    lenv,
                    (s: Frames) => reduce(s, lenv),
                    List(newE)
                  )
                }
                case e: IRuntimeException => IError(c, lenv, e, List())
              }
            }
            case e: IRuntimeException => IError(c, lenv, e, List())
          }
        }

        /** IN: v1 op s2, ...
          * OUT: s2, v1 op [], ...
          */
        case IContext(
              IIntIntIntOp(v1: ICheckedValue, s2: ICheckedSerious, op),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s2, env) :: IContext(
                IIntIntIntOp(v1, IHole(), op),
                env
              ) :: xs,
              lenv
            )
          )

        /** IN: s1 op s2, ...
          * OUT: s1, [] op s2, ...
          */
        case IContext(
              IIntIntIntOp(s1: ICheckedSerious, s2: TypeDerivation, op),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(
                IIntIntIntOp(IHole(), s2, op),
                env
              ) :: xs,
              lenv
            )
          )

        /** IN: v, [] op t2, ...
          * OUT: v op t2, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IIntIntIntOp(IHole(), t2, op),
              env2
            ) :: xs =>
          More(() =>
            reduce(IContext(IIntIntIntOp(v, t2, op), env2) :: xs, lenv)
          )

        /** IN: v, v1 op [], ...
          * OUT: v1 op v, ...
          */
        case IContext(v: ICheckedValue, env1) :: IContext(
              IIntIntIntOp(v1, IHole(), op),
              env2
            ) :: xs =>
          More(() =>
            reduce(IContext(IIntIntIntOp(v1, v, op), env2) :: xs, lenv)
          )

        /** pairs */
        /** IN: (v1, v2), ...
          * OUT: (v1, v2)_v, ...
          */
        case IContext(e @ IPair(v1: IValue, v2: IValue), env) :: xs => {
          val newV = IPairValue(v1, v2)
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** IN: (v1, s2), ...
          * OUT: s2, (v1, []), ...
          */
        case IContext(IPair(v1: IValue, s2: ISerious), env) :: xs =>
          More(() =>
            reduce(
              IContext(s2, env) :: IContext(IPair(v1, IHole()), env) :: xs,
              lenv
            )
          )

        /** IN: (s1, s2), ...
          * OUT: s1, ([], s2), ...
          */
        case IContext(IPair((s1: ISerious), s2: TypeDerivation), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IPair(IHole(), s2), env) :: xs,
              lenv
            )
          )

        /** IN: v, ([], t2), ...
          * OUT: (v, t2), ...
          */
        case IContext((v: IValue), env1) :: IContext(
              IPair(IHole(), t2),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IPair(v, t2), env2) :: xs, lenv))

        /** IN: v, (v1, []), ...
          * OUT: (v1, v), ...
          */
        case IContext((v: IValue), env1) :: IContext(
              IPair(v1, IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IPair(v1, v), env2) :: xs, lenv))

        /** IN: first (g <= _ : *), ...
          * OUT: first ((g <= _ : *) <= * x * : * x *), ...
          */
        case IContext(
              e @ IFirst(v1 @ IAscVal(SubValue(g: IValue, _), Unknown())),
              env
            ) :: xs => {
          val newV = IFirst(
            IAsc(
              SubValue(v1, PairType(Unknown(), Unknown())),
              PairType(Unknown(), Unknown())
            )
          )
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** IN: first (v1, v2), ...
          * OUT: v1, ...
          */
        case IContext(
              e @ IFirst(IPairValue(v1: IValue, v2: IValue)),
              env
            ) :: xs => {
          val newV = v1
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** IN: second (g <= _ : *), ...
          * OUT: second ((g <= _ : *) <= * x * : * x *), ...
          */
        case IContext(
              e @ ISecond(v1 @ IAscVal(SubValue(g: IValue, _), Unknown())),
              env
            ) :: xs => {
          val newV = ISecond(
            IAsc(
              SubValue(v1, PairType(Unknown(), Unknown())),
              PairType(Unknown(), Unknown())
            )
          )
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** IN: second (v1, v2), ...
          * OUT: v2, ...
          */
        case IContext(
              e @ ISecond(IPairValue(v1: IValue, v2: IValue)),
              env
            ) :: xs => {
          val newV = v2
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** STEP-EVAL
          * IN: first s1, ...
          * OUT: s1, first [], ...
          */
        case IContext(IFirst((s1: ISerious)), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IFirst(IHole()), env) :: xs,
              lenv
            )
          )

        /**  STEP-EVAL
          * IN: second s1, ...
          * OUT: s1, second [], ...
          */
        case IContext(ISecond((s1: ISerious)), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(ISecond(IHole()), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, first [], ...
          * OUT: first v, ...
          */
        case IContext(v: IValue, env1) :: IContext(
              IFirst(IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IFirst(v), env2) :: xs, lenv))

        /** STEP-EVAL
          * IN: v, second [], ...
          * OUT: second v, ...
          */
        case IContext(v: IValue, env1) :: IContext(
              ISecond(IHole()),
              env2
            ) :: xs =>
          More(() => reduce(IContext(ISecond(v), env2) :: xs, lenv))

        /** sums */
        /** IN: inj1 v, ...
          * OUT: inj1_v v, ...
          */
        case IContext(e @ IInj1(v: IValue, ty), env) :: xs => {
          val newV = IInj1Value(v, ty)
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** IN: inj2 v, ...
          * OUT: inj2_v v, ...
          */
        case IContext(e @ IInj2(v: IValue, ty), env) :: xs => {
          val newV = IInj2Value(v, ty)
          Step(
            c,
            lenv,
            IContext(newV, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(newV)
          )
        }

        /** STEP-EVAL
          * IN: inj1 s, ...
          * OUT: s, inj1 [], ...
          */
        case IContext(IInj1((s1: ISerious), ty), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IInj1(IHole(), ty), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: inj2 s, ...
          * OUT: s, inj2 [], ...
          */
        case IContext(IInj2((s1: ISerious), ty), env) :: xs =>
          More(() =>
            reduce(
              IContext(s1, env) :: IContext(IInj2(IHole(), ty), env) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, inj1 [], ...
          * OUT: inj1 v, ...
          */
        case IContext(v: IValue, env1) :: IContext(
              IInj1(IHole(), ty),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IInj1(v, ty), env2) :: xs, lenv))

        /** STEP-EVAL
          * IN: v, inj2 [], ...
          * OUT: inj2 v, ...
          */
        case IContext(v: IValue, env1) :: IContext(
              IInj2(IHole(), ty),
              env2
            ) :: xs =>
          More(() => reduce(IContext(IInj2(v, ty), env2) :: xs, lenv))

        /** IN: case (g <= _: *) of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          * OUT: case ((g <= _: *) <= * + * : * + *) of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          */
        case IContext(
              e @ ICase(
                v1 @ IAscVal(SubValue(g: IValue, _), Unknown()),
                x1,
                t1,
                x2,
                t2
              ),
              env
            ) :: xs => {
          val newE = ICase(
            IAsc(
              Sub(v1, SumType(Unknown(), Unknown())),
              SumType(Unknown(), Unknown())
            ),
            x1,
            t1,
            x2,
            t2
          )
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(t1)
          )
        }

        /** IN: case inj1_v v of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          * OUT: t1[v/x1], ...
          */
        case IContext(
              e @ ICase(IInj1Value(v: IValue, ty), x1, t1, x2, t2),
              env
            ) :: xs => {
          val newE = subst(t1, x1, v)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(t1)
          )
        }

        /** IN: case inj2_v v of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          * OUT: t2[v/x2], ...
          */
        case IContext(
              e @ ICase(IInj2Value(v: IValue, ty), x1, t1, x2, t2),
              env
            ) :: xs => {
          val newE = subst(t2, x2, v)
          Step(
            c,
            lenv,
            IContext(newE, env) :: xs,
            lenv,
            (s: Frames) => reduce(s, lenv),
            List(t1)
          )
        }

        /** STEP-EVAL
          * IN: case s1 of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          * OUT: s1, case [] of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          */
        case IContext(
              ICase((s: ISerious), (x1: IVar), t1, (x2: IVar), t2),
              env
            ) :: xs =>
          More(() =>
            reduce(
              IContext(s, env) :: IContext(
                ICase(IHole(), (x1: IVar), t1, (x2: IVar), t2),
                env
              ) :: xs,
              lenv
            )
          )

        /** STEP-EVAL
          * IN: v, case [] of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          * OUT: case v of { inj1 x1 => t1 | inj2 x2 => t2 }, ...
          */
        case IContext(v: IValue, env1) :: IContext(
              ICase(IHole(), x1, t11, x2, t2),
              env2
            ) :: xs =>
          More(() =>
            reduce(IContext(ICase(v, x1, t11, x2, t2), env2) :: xs, lenv)
          )

        /** IN: v
          * OUT: WE ARE DONE(v)!
          */
        case IContext(v: IValue, env) :: Nil => Done(v)

        /** default case is an exception */
        case IContext(x, env) :: xs =>
          throw new Exception(s"Can't match ${x}")
      }
    }

    /** add the configuration to the list of configurations so far for latex logging */
    def appendLatex(conf: Configuration): Unit = {
      conf.c.t.getLatexDerivationTree
      conf.c.env.toLatex
      conf.lenv.toLatex
      configurations = configurations :+ IConfLatex(
        conf.c.t.getLatexDerivationTree,
        conf.c.env.toLatex,
        conf.lenv.toLatex
      )
    }

    /** The Trampoline trait has three implementations:
      * A Done state meaning that we are done.
      * A More state meaning that we took an intermediate step but we should not pay attention to it.
      * A Step state meaning that we took a step and we must pay attention and log it to the interface
      */
    sealed trait Trampoline {

      /** This function is the main function of the trampoline. It is called by the interface to take a step
        * in the evaluation of the term. It returns a Result object that contains the result of the evaluation
        * and the configurations that were generated during the evaluation.
        */
      def step(implicit o: IOptions): Result = {
        this match {
          /** if we are done we append the current configuration to the list of configurations and return a Result. */
          case Done(a) => {
            appendLatex(current)
            Result(Left(a), configurations, nstep, true)
          }
          /** We took a step but we shouldn't stop. Let us continue reducing... */
          case More(t) => t().step

          /** We took an important step of reduction. Lets take a breath, increase the number of steps and log
            * the current configuration. We also mark with a box the redex of the type derivation.
            */
          case s @ Step(s1, lenv1, s2, lenv2, t, _, _) => {
            nstep += 1
            implicit val substitutionMode = s.substitutionMode
            val iterm = reconstructITerm(s1)
            appendLatex(Configuration(IContext(iterm, s1(0).env), lenv1))
            current =
              Configuration(IContext(reconstructITerm(s2), s2(0).env), lenv2)
            if (nstep < fromStep + stepSize) {
              s2.map {
                _.t.unboxLevel
              }
              t(s2).step
            } else {
              Result(Left(iterm), configurations, nstep, false)
            }
          }
          /** In case we got an error we just stop. Similar to the Done step. */
          case IError(s1, lenv1, error, toBoxExtra) => {
            val iterm = reconstructITerm(s1)
            appendLatex(Configuration(IContext(iterm, s1(0).env), lenv1))
            Result(Right(error), configurations, nstep, true)
          }

        }
      }
    }

    /** This class represents the final state of the evaluation. It contains the result of the evaluation.
      * @param a
      */
    case class Done(a: IValue) extends Trampoline

    /** This class represents a state where we took a step but we should not stop.
      * @param a A continuation to keep reducing
      */
    case class More(a: () => Trampoline) extends Trampoline

    /** This class represents a state where we took a step and we should stop.
      * It contains the new frames, the new linear environment, the new continuation,
      * the elements to highlight and the elements to box.
      * @param s1 The frames before the steps
      * @param lenv1 The linear environment before the step
      * @param s2 The frames after the step
      * @param lenv2 The linear environment after the step
      * @param a The continuation
      * @param toHighlight The elements to highlight
      * @param toBoxExtra The elements to box
      * @param substitutionMode The substitution mode
      */
    case class Step(
        s1: Frames,
        lenv1: LinearEnv,
        s2: Frames,
        lenv2: LinearEnv,
        a: Frames => Trampoline,
        toHighlight: List[Highlighteable] = Nil,
        toBoxExtra: List[Boxeable] = Nil
    )(implicit val substitutionMode: SubstitutionModel)
        extends Trampoline {
      toHighlight.map {
        _.startHighlightTimer
      }
      (toBoxExtra ++ s1.headOption.map { s => List(s.t) }.getOrElse(Nil)).map {
        boxeable =>
          boxeable.startBoxedTimer
      }
    }

    /** This class represents an error in the evaluation of the program. It stores many things beside the error itself.
      *
      * @param s1               the current frames
      * @param lenv1            the current linear environment
      * @param error            the error
      * @param toBoxExtra       a list of extra elements to be boxed for the latex output
      * @param substitutionMode the substitution mode
      */
    case class IError(
        s1: Frames,
        lenv1: LinearEnv,
        error: IRuntimeException,
        toBoxExtra: List[Boxeable] = Nil
    )(implicit val substitutionMode: SubstitutionModel)
        extends Trampoline {
      (toBoxExtra ++ s1.headOption.map { s => List(s.t) }.getOrElse(Nil)).map {
        boxeable =>
          boxeable.startBoxedTimer
      }
    }

    /** this function reconstruct the type derivation, by iterating over all current frames. This is
      * mainly used to convert the current type derivation to latex
      */
    @tailrec
    private def reconstructITerm(c: Frames): TypeDerivation = {
      c match {
        case IContext(t, env) :: Nil => t

        case IContext(v, env1) :: IContext(IIte(IHole(), t1, t2), env2) :: xs =>
          reconstructITerm(IContext(IIte(v, t1, t2), env2) :: xs)

        case IContext(v, env1) :: IContext(IApp(IHole(), t2), env2) :: xs =>
          reconstructITerm(IContext(IApp(v, t2), env2) :: xs)

        case IContext(v, env1) :: IContext(IPair(IHole(), t2), env2) :: xs =>
          reconstructITerm(IContext(IPair(v, t2), env2) :: xs)

        case IContext(v, env1) :: IContext(IPair(v1, IHole()), env2) :: xs =>
          reconstructITerm(IContext(IPair(v1, v), env2) :: xs)

        case IContext(v, env1) :: IContext(IMerge(IHole(), t2), env2) :: xs =>
          reconstructITerm(IContext(IMerge(v, t2), env2) :: xs)

        case IContext(v, env1) :: IContext(IMerge(v1, IHole()), env2) :: xs =>
          reconstructITerm(IContext(IMerge(v1, v), env2) :: xs)

        case IContext(v, env1) :: IContext(IApp(v1, IHole()), env2) :: xs =>
          reconstructITerm(IContext(IApp(v1, v), env2) :: xs)

        case IContext(v, env1) :: IContext(IAppRT(v1, IHole()), env2) :: xs =>
          reconstructITerm(IContext(IAppRT(v1, v), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IBoolOp(IHole(), t2, op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IBoolOp(v, t2, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IBoolOp(v1, IHole(), op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IBoolOp(v1, v, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IBoolUnOp(IHole(), op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IBoolUnOp(v, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IIntIntIntOp(IHole(), t2, op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IIntIntIntOp(v, t2, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IIntIntIntOp(v1, IHole(), op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IIntIntIntOp(v1, v, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IIntIntBoolOp(IHole(), t2, op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IIntIntBoolOp(v, t2, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IIntIntBoolOp(v1, IHole(), op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IIntIntBoolOp(v1, v, op), env2) :: xs)

        case IContext(v, env1) :: IContext(
              IIntIntIntOp(v1, IHole(), op),
              env2
            ) :: xs =>
          reconstructITerm(IContext(IIntIntIntOp(v1, v, op), env2) :: xs)

        case IContext(v, env1) :: IContext(ILet(x, IHole(), t2), env2) :: xs =>
          reconstructITerm(IContext(ILet(x, v, t2), env2) :: xs)

        case IContext(v, env1) :: IContext(
              ICase(IHole(), x1, t1, x2, t2),
              env2
            ) :: xs =>
          reconstructITerm(IContext(ICase(v, x1, t1, x2, t2), env2) :: xs)

        case IContext(v, env1) :: IContext(IAscVal(IHole(), t), env2) :: xs =>
          reconstructITerm(IContext(IAscVal(v, t), env2) :: xs)

        case IContext(v, env1) :: IContext(IAsc(IHole(), t), env2) :: xs =>
          reconstructITerm(IContext(IAsc(v, t), env2) :: xs)

        case IContext(v, env1) :: IContext(IFirst(IHole()), env2) :: xs =>
          reconstructITerm(IContext(IFirst(v), env2) :: xs)

        case IContext(v, env1) :: IContext(ISecond(IHole()), env2) :: xs =>
          reconstructITerm(IContext(ISecond(v), env2) :: xs)

        case IContext(v, env1) :: IContext(IInj1(IHole(), ty), env2) :: xs =>
          reconstructITerm(IContext(IInj1(v, ty), env2) :: xs)

        case IContext(v, env1) :: IContext(IInj2(IHole(), ty), env2) :: xs =>
          reconstructITerm(IContext(IInj2(v, ty), env2) :: xs)

        case IContext(v, env1) :: IContext(IRecord(l, IHole()), env2) :: xs =>
          reconstructITerm(IContext(IRecord(l, v), env2) :: xs)
        //case IContext(v, env1) :: IContext(IMergeValue(l, IHole()), env2) :: xs => reconstructITerm(IContext(IMergeValue(l, v), env2) :: xs)
        case IContext(v, env1) :: IContext(IProj(IHole(), l), env2) :: xs =>
          reconstructITerm(IContext(IProj(v, l), env2) :: xs)

        case IContext(v, env1) :: IContext(Sub(IHole(), t), env2) :: xs =>
          reconstructITerm(IContext(Sub(v, t), env2) :: xs)
        case IContext(v, env1) :: IContext(SubValue(IHole(), t), env2) :: xs =>
          reconstructITerm(IContext(SubValue(v, t), env2) :: xs)

        case _ => throw new Error("wrong " + c)

      }
    }

  }

}
