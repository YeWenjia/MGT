package glang.typing

import glang.syntax.GType

/** This trait represent a judgment. For now we only have subtyping but this can be extended with any
  * other judgment
  */
trait Judgment {

  /** the latex string representation of the relation */
  val op: String

  /** Convert the judgment to latex
    *
    * @param o The options to use in the conversion
    * @return The latex representation of the judgment
    */
  def toLatex(implicit o: IOptions): String
}

/** This class represents a consistent subtyping judgment.
  *
  * @param t1 The first/lhs type
  * @param t2 The second/rhs type
  */
case class CSubtyping(t1: GType, t2: GType) extends Judgment {
  val op = "\\lesssim"

  def toLatex(implicit o: IOptions): String = {
    val judgment = t1.toLatex + " " + op + " " + t2.toLatex
    judgment
  }
}
