package glang.typing

import glang.syntax.GTypes._
import glang.syntax.Syntax._
import glang.syntax._
import glang.typing.Typing.IDisjointError
import Typing.ITypeError
import glang.runtime.Runtime.RuntimeEnvironment
import glang.runtime.IRuntimeException

//implicit def Ivar2Var(x: IVar) = Var(x.x)

/** This trait represent a result of an evaluation
  */
trait IResult

/** Two cases of errors: Type error and Ambiguity errors */
case class IErrorT(msg: String = "")
    extends IRuntimeException(s"Type error! ${msg}")

case class IErrorA(msg: String = "")
    extends IRuntimeException(s"Ambiguity error! ${msg}")

trait TypeDerivation
    extends Term
    with Highlighteable
    with Boxeable
    with Latexable
    with IResult {

  /** Every type derivation has a type */
  def tpe: GType

  /** Infer mode or check mode (1 for infer, 2 for check)
    */
  val mode: Int = 1

  /** Function to do a post-processing of the string returning it for latex printing
    * @param s The string to process
    * @param o The options to use in the conversion
    * @return The processed string
    */
  def postProcess(s: String)(implicit o: IOptions): String = {
    val text = s
    /* highlighting and boxing of text */
    val htext = if (highlight == 1) s"\\highlight{$text}" else text
    if (boxed == 1) s"\\bbox[1px,border:2px solid red]{$htext}" else htext
  }

  /** The subterms of the derivation
    * By default they are empty
    */
  val subTerms: Seq[TypeDerivation] = Nil

  /** The judgments of the derivation.
    * By default empty
    * @param g The runtime environment
    * @return The judgments of the derivation
    */
  def judgments(g: RuntimeEnvironment): Seq[Judgment] = Nil

  /** Put a => arrow for infer mode, or a <= for check mode in latex
    * @param s The string to put the arrow
    * @param o The options to use in the conversion
    * @return
    */
  def addArrow(s: String)(implicit o: IOptions) = {
    if (mode == 1) s + s" \\Rightarrow \\TermT{${tpe.toLatex}}"
    else s + s" \\Leftarrow \\TermT{${tpe.toLatex}}"
  }

  /** The name of the derivation
    */
  def derivationName: String

  /** Get the latex representation of the term
    * @param o The options to use in the conversion
    * @return
    */
  def getLatexDerivationTree(implicit o: IOptions): LatexDerivationTree = {
    LatexDerivationTree(
      addArrow(toLatex),
      subTerms.map { t => t.getLatexDerivationTree }.toList,
      judgments(o.g).map { j => LatexJudgment(j.toLatex) }.toList,
      derivationName
    )
  }

  /** decrease the highlight counter by one */
  override def unhighlightLevel: Unit = {
    highlight -= 1
    subTerms.map {
      _.unhighlightLevel
    }
  }

  /** decrease the box level by one */
  override def unboxLevel: Unit = {
    if (boxed > 0) boxed -= 1
    subTerms.map {
      _.unboxLevel
    }
  }

  /** increase the box level by one */
  override def boxLevel: Unit = {
    boxed += 1
    subTerms.map {
      _.boxLevel
    }
  }

}

/** values * */

/** This trait represents any tree derivation of a value on runtime
  */
trait IValue extends TypeDerivation {}

/** A simple value is something that is not a function */
trait SimpleValue extends IValue

/** A serious expression is a redex */
trait ISerious extends TypeDerivation

/** A derivation tree of the top value */
case class ITop() extends SimpleValue {
  def tpe = TopType()

  def pprint = "⊤"

  override def toLatex(implicit o: IOptions): String = "\\{\\}"

  def derivationName = "TYP-TOP"
}

/** A derivation tree of a number
  * @param v The integer value
  */
case class INumber(v: Int) extends SimpleValue {
  def tpe = IntType()

  def pprint = v.toString

  def toLatex(implicit o: IOptions): String = postProcess(pprint)

  def derivationName = "TYP-LIT"
}

/** A derivation tree of a boolean
  * @param b The boolean value
  */
case class IBool(b: Boolean) extends SimpleValue {
  def tpe = BoolType()

  def pprint = b.toString

  def toLatex(implicit o: IOptions): String = postProcess("\\" + pprint)

  def derivationName = "TYP-LIT"
}

/** A derivation tree of a unit value
  */
case class IUnit() extends SimpleValue {

  def tpe = UnitType()

  def pprint = "()"

  def toLatex(implicit o: IOptions): String = postProcess("()")

  def derivationName = "TYP-LIT"
}

/** A derivation tree of a variable
  * @param x The name of the variable
  * @param ty The type of the variable
  */
case class IVar(x: String, ty: GType) extends ISerious {

  def tpe = ty

  def pprint = x.toString

  def toLatex(implicit o: IOptions): String = postProcess(
    "\\texttt{" + pprint + s"}"
  )

  def derivationName = "TYP-VAR"
}

/** A derivation tree of a boolean binary operation
  * @param t1 The first term in the operation
  * @param t2 The second term in the operation
  * @param op The operation to perform
  */
case class IBoolOp(t1: TypeDerivation, t2: TypeDerivation, op: String)
    extends ISerious {

  def tpe = {
    if ((t1.tpe eq BoolType()) && (t2.tpe eq BoolType())) BoolType()
    else if (t1.tpe != BoolType())
      throw new ITypeError(t1, t1.tpe, BoolType())
    else throw new ITypeError(t2, t2.tpe, BoolType())
  }

  def pprint = t1.pprint + " " + op + " " + t2.pprint

  override def debug = t1.debug + " " + op + " " + t2.debug

  def opToLatex(op: String) = op match {
    case andS.parser => "\\wedge"
    case orS.parser  => "\\vee"
    case _           => op
  }

  def toLatex(implicit o: IOptions) = postProcess(
    "(" + t1.toLatex + " " + opToLatex(op) + " " + t2.toLatex + ")"
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-BOP"
}

/** A derivation tree of a boolean unary operation
  * @param t1 The term to apply the operation to
  * @param op The operation to perform
  */
case class IBoolUnOp(t1: TypeDerivation, op: String) extends ISerious {
  def tpe = if (t1.tpe eq BoolType()) BoolType()
  else {
    throw new ITypeError(t1, t1.tpe, BoolType())
  }

  def pprint = op + " " + t1.pprint

  override def debug = op + " " + t1.debug

  def opToLatex(op: String) = op match {
    case _ => op
  }

  def toLatex(implicit o: IOptions) = postProcess(
    "(" + opToLatex(op) + " " + t1.toLatex + ")"
  )

  override val subTerms = Seq(t1)

  def derivationName = "Typ-BOP"
}

/** A derivation tree of a int -> int -> bool operation
  * @param t1 The first term in the operation
  * @param t2 The second term in the operation
  * @param op The operation to perform
  */
case class IIntIntBoolOp(t1: TypeDerivation, t2: TypeDerivation, op: String)
    extends ISerious {
  def tpe = {
    if ((t1.tpe eq IntType()) && (t2.tpe eq IntType())) BoolType()
    else if (t1.tpe != IntType()) throw new ITypeError(t1, t1.tpe, IntType())
    else throw new ITypeError(t2, t2.tpe, IntType())
  }

  def pprint = t1.pprint + " " + op + " " + t2.pprint

  override def debug = t1.debug + " " + op + " " + t2.debug

  def opToLatex(op: String) = op match {
    case "<" => "\\lt"
    case ">" => "\\gt"
    case _   => op
  }

  def toLatex(implicit o: IOptions) = postProcess(
    "(" + t1.toLatex + " " + opToLatex(op) + " " + t2.toLatex + ")"
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-ROP"
}

/** A derivation tree of a int -> int -> int operation
  * @param t1 The first term in the operation
  * @param t2 The second term in the operation
  * @param op The operation to perform
  */
case class IIntIntIntOp(t1: TypeDerivation, t2: TypeDerivation, op: String)
    extends ISerious {
  def tpe = {
    if ((t1.tpe eq IntType()) && (t2.tpe eq IntType())) IntType()
    else if (t1.tpe != IntType()) throw new ITypeError(t1, t1.tpe, IntType())
    else throw new ITypeError(t2, t2.tpe, IntType())
  }

  def pprint = t1.pprint + " " + op + " " + t2.pprint

  override def debug = t1.debug + " " + op + " " + t2.debug

  def opToLatex(op: String) = op match {
    case _ => op
  }

  def toLatex(implicit o: IOptions) = postProcess(
    "(" + t1.toLatex + " " + opToLatex(op) + " " + t2.toLatex + ")"
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-MULT"
}

/** A derivation tree of a pair of terms
  * @param t1 The first term in the pair
  * @param t2 The second term in the pair
  */
case class IPair(t1: TypeDerivation, t2: TypeDerivation) extends ISerious {
  def tpe = PairType(t1.tpe, t2.tpe)

  def pprint = "<" + t1.pprint + ", " + t2.pprint + ">"

  override def debug = "P<" + t1.debug + ", " + t2.debug + ">"

  def toLatex(implicit o: IOptions) = postProcess(
    "(" + t1.toLatex + ", " + t2.toLatex + ")"
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-APAIR"
}

/** A derivation tree of a pair of values.
  * This tree is by itself a value. This is required to avoid reducing pairs in an infinite loop.
  * @param t1 The first value in the pair
  * @param t2 The second value in the pair
  */
case class IPairValue(t1: TypeDerivation, t2: TypeDerivation)
    extends SimpleValue {

  def tpe = PairType(t1.tpe, t2.tpe)

  def pprint = "<" + t1.pprint + ", " + t2.pprint + ">"

  override def debug = "V<" + t1.debug + ", " + t2.debug + ">"

  def toLatex(implicit o: IOptions) = postProcess(
    "(" + t1.toLatex + ", " + t2.toLatex + ")"
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-APAIR"
}

/** A derivation tree of a merge
  * @param t1 The first term in the merge
  * @param t2 The second term in the merge
  */
case class IMerge(t1: TypeDerivation, t2: TypeDerivation) extends ISerious {
  def tpe = {
    if (!(t1.tpe * t2.tpe)) throw new IDisjointError(this, t1.tpe, t2.tpe)
    IntersectionType(t1.tpe, t2.tpe)
  }

  def pprint = "(" + t1.pprint + ",, " + t2.pprint + ")"

  override def debug = "(" + t1.debug + ",, " + t2.debug + ")"

  def toLatex(implicit o: IOptions) = postProcess(
    "" + t1.toLatex + ",, " + t2.toLatex + ""
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "Type-merge"
}

/** A derivation tree of a merge of values. This to avoid infinitely reducing merges.
  * @param t1 The first value in the merge
  * @param t2 The second value in the merge
  */
case class IMergeValue(t1: IValue, t2: IValue) extends SimpleValue {

  def tpe = {
    t1.tpe * t2.tpe
    IntersectionType(t1.tpe, t2.tpe)
  }

  def pprint = "(" + t1.pprint + ", " + t2.pprint + ")"

  override def debug = "V(" + t1.debug + ",, " + t2.debug + ")"

  def toLatex(implicit o: IOptions) = postProcess(
    "" + t1.toLatex + ",, " + t2.toLatex + ""
  )

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-MERGE"
}

/** A derivation tree of a left injection
  * @param t The term to inject
  * @param tpe2 The type of the sum type
  */
case class IInj1(t: TypeDerivation, tpe2: GType) extends ISerious {
  def tpe = SumType(t.tpe, tpe2)

  def pprint = "Pinj1(" + t.pprint + ")"

  override def debug = "Pinj1(" + t.debug + ")"

  def toLatex(implicit o: IOptions) = postProcess(
    s"\\injone{${t.toLatex}}{${tpe.toLatex}}"
  )

  override val subTerms = Seq(t)

  def derivationName = "TYP-INJ1"
}

/** A derivation tree of a left injection of values to avoid infinite reduction.
  * @param t The value to inject
  * @param tpe2 The type of the sum type
  */
case class IInj1Value(t: TypeDerivation, tpe2: GType) extends SimpleValue {
  def tpe = SumType(t.tpe, tpe2)

  def pprint = "Vinj1(" + t.pprint + ")"

  override def debug = "Vinj1(" + t.debug + ")"

  def toLatex(implicit o: IOptions) = postProcess(
    s"\\injone{${t.toLatex}}{${tpe.toLatex}}"
  )

  override val subTerms = Seq(t)

  def derivationName = "INJ1"
}

/** A derivation tree of a right injection
  * @param t The term to inject
  * @param tpe2 The type of the sum type
  */
case class IInj2(t: TypeDerivation, tpe2: GType) extends ISerious {
  def tpe = SumType(tpe2, t.tpe)

  def pprint = "Pinj2(" + t.pprint + ")"

  override def debug = "Vinj2(" + t.debug + ")"

  def toLatex(implicit o: IOptions) = postProcess(
    s"\\injtwo{${t.toLatex}}{${tpe.toLatex}}"
  )

  override val subTerms = Seq(t)

  def derivationName = "TYP-INJ2"
}

/** A derivation tree of a right injection of values to avoid infinite reduction.
  * @param t The value to inject
  * @param tpe2 The type of the sum type
  */
case class IInj2Value(t: TypeDerivation, tpe2: GType) extends SimpleValue {
  def tpe = SumType(tpe2, t.tpe)

  def pprint = "Vinj2(" + t.pprint + ")"

  override def debug = "Vinj2(" + t.debug + ")"

  def toLatex(implicit o: IOptions) = postProcess(
    s"\\injtwo{${t.toLatex}}{${tpe.toLatex}}"
  )

  override val subTerms = Seq(t)

  def derivationName = "INJ2"
}

/** A derivation tree of an if-then-else
  * @param t1 The condition
  * @param t2 The then branch
  * @param t3 The else branch
  */
case class IIte(t1: TypeDerivation, t2: TypeDerivation, t3: TypeDerivation)
    extends ISerious {

  def tpe = {
    if ((t1.tpe eq BoolType()) && (t2.tpe eq t3.tpe)) t2.tpe
    else {
      if (!(t1.tpe eq BoolType()))
        throw new ITypeError(this, t1.tpe, BoolType())
      else
        throw new ITypeError(t3, t3.tpe, t2.tpe)
    }
  }

  def pprint = "if " + t1.pprint + " then " + t2.pprint + " else " + t3.pprint

  override def debug =
    "if " + t1.debug + " then " + t2.debug + " else " + t3.debug

  def toLatex(implicit o: IOptions): String = postProcess(
    "(\\ite{" + t1.toLatex + "}{" + t2.toLatex + "}{" + t3.toLatex + "})"
  )

  override val subTerms = Seq(t1, t2, t3)

  def derivationName = "TYP-IF"
}

/** A derivation tree of the TYP-APP application rule
  * @param t1 The function to apply
  * @param t2 The argument to apply the function to
  */
case class IApp(t1: TypeDerivation, t2: TypeDerivation) extends ISerious {

  def tpe = {
    val t1tpe = t1.tpe
    val a1 = dom(t1tpe)
    val a2 = cod(t1tpe)

    if (t2.tpe eq a1) a2
    else {
      throw new ITypeError(this, t2.tpe, a1)
    }
  }

  def pprint = t1.pprint + " " + t2.pprint

  override def debug = t1.debug + " " + t2.debug

  def toLatex(implicit o: IOptions): String = {

    postProcess("(" + t1.toLatex + t2.toLatex + ")")
  }

  override val subTerms = Seq(t1, t2)
  /*override def judgments(g: RuntimeEnvironment) = {
    val (xp, ty1, ty2, sep) = destr(g)
    Seq(Leq(t2.se(g).dotit(), xp.s))
  }*/

  def derivationName = "TYP-APP"
}

/** A derivation tree of the annotation rule
  * @param e The term to annotate
  * @param t The type to annotate the term with
  */
case class IAsc(e: TypeDerivation, t: GType) extends ISerious {
  def tpe = {
    e.tpe
    if (e.tpe eq t) t
    else throw new ITypeError(e, e.tpe, t)
  }

  def pprint = "(" + e.pprint + " : " + t.pprint + ")"

  override def debug = "(" + e.debug + " : " + t.debug + ")"

  def toLatex(implicit o: IOptions): String = postProcess(
    "(" + e.toLatex + " : " + t.toLatex + ")"
  )

  override val subTerms = Seq(e)

  def derivationName = "TYP-ANNO"
}

/** A derivation tree of the annotation rule for values
  * @param e The value to annotate
  * @param t The type to annotate the value with
  */
case class IAscVal(e: TypeDerivation, t: GType)
    extends ISerious
    with SimpleValue {
  def tpe = {
    //println(this)
    //println(e.tpe, t)
    if (e.tpe eq t) t
    else throw new ITypeError(e, e.tpe, t)
  }

  def pprint = "(" + e.pprint + " : " + t.pprint + ")"

  override def debug = "(" + e.debug + " :v " + t.debug + ")"

  def toLatex(implicit o: IOptions): String = postProcess(
    "(" + e.toLatex + " : " + t.toLatex + ")"
  )

  override val subTerms = Seq(e)

  def derivationName = "TYP-ANNO"
}

/** A derivation tree of a record
  * @param l The label of the record
  * @param t The term to bind to the label
  */
case class IRecord(l: String, t: TypeDerivation) extends ISerious {

  def tpe = RecordType(l, t.tpe)

  def pprint = s"{${l} = ${t.pprint}}"

  override def debug = s"{${l} = ${t.debug}}"

  def toLatex(implicit o: IOptions): String =
    s"\\{\\mathit{${l}} = ${t.toLatex}\\}"

  override val subTerms = Seq(t)

  def derivationName = "TY-RCD"
}

/** A derivation tree of a record value
  * @param l The label of the record
  * @param t The value to bind to the label
  */
case class IRecordValue(l: String, t: IValue) extends SimpleValue {

  def tpe = RecordType(l, t.tpe)

  def pprint = s"{${l} = ${t.pprint}}"

  override def debug = s"V{${l} = ${t.debug}}"

  def toLatex(implicit o: IOptions): String =
    s"\\{\\mathit{${l}} = ${t.toLatex}\\}"

  override val subTerms = Seq(t)

  def derivationName = "TY-RCD"
}

/** A derivation tree of a projection
  * @param t The term to project
  * @param l The label to project
  */
case class IProj(t: TypeDerivation, l: String) extends ISerious {

  def tpe = proj(l, t.tpe)

  def pprint = s"${t.pprint}.${l}"

  override def debug = s"${t.debug}.${l}"

  def toLatex(implicit o: IOptions): String = s"${t.toLatex}.\\mathit{${l}}"

  override val subTerms = Seq(t)

  def derivationName = "TY-PROJ"
}

/** A derivation tree of a let expression
  * @param x The variable to bind
  * @param t1 The term to bind the variable to
  * @param t2 The term to evaluate
  */
case class ILet(x: IVar, t1: TypeDerivation, t2: TypeDerivation)
    extends ISerious {
  def tpe = t2.tpe

  def pprint = s"let ${x.pprint} = ${t1.pprint} in ${t2.pprint}"

  override def debug = s"let ${x.debug} = ${t1.debug} in ${t2.debug}"

  def toLatex(implicit o: IOptions): String = {
    postProcess(s"\\lett{${x.toLatex}}{${t1.toLatex}}{${t2.toLatex}}")
  }

  override val subTerms = Seq(t1, t2)

  def derivationName = "TYP-LET"
}

/** A derivation tree of a first operation over a pair
  * @param t The term to evaluate
  */
case class IFirst(t: TypeDerivation) extends ISerious {
  def tpe = pi1(t.tpe)

  def pprint = "fst(" + t.pprint + ")"

  override def debug = "fst(" + t.debug + ")"

  def toLatex(implicit o: IOptions): String = postProcess(
    "\\fst^{" + "}(" + t.toLatex + ")"
  )

  override val subTerms = Seq(t)

  def derivationName = "TYP-FST"
}

/** A derivation tree of a second operation over a pair
  * @param t The term to evaluate
  */
case class ISecond(t: TypeDerivation) extends ISerious {
  def tpe = pi2(t.tpe)

  def pprint = "snd(" + t.pprint + ")"

  override def debug = "snd(" + t.debug + ")"

  def toLatex(implicit o: IOptions): String = postProcess(
    "\\snd^{" + "}(" + t.toLatex + ")"
  )

  override val subTerms = Seq(t)

  def derivationName = "TYP-SND"
}

/** A derivation tree of a case expression
  * @param t The term to evaluate
  * @param x1 The variable to bind the left branch to
  * @param t1 The term to evaluate if the left branch is taken
  * @param x2 The variable to bind the right branch to
  * @param t2 The term to evaluate if the right branch is taken
  */
case class ICase(
    t: TypeDerivation,
    x1: IVar,
    t1: TypeDerivation,
    x2: IVar,
    t2: TypeDerivation
) extends ISerious {

  def tpe = {
    val ty1 = t1.tpe
    val ty2 = t2.tpe
    //println(ty1, ty2)
    if (ty1 eq ty2) {
      ty1
    } else throw new Exception(ty1.pprint + " is not equal to " + ty2.pprint)
  }

  def pprint =
    s"case ${t.pprint} of {${x1.pprint} => ${t1.pprint}} {${x2.pprint} => ${t2.pprint}}"

  override def debug =
    s"case ${t.debug} of {${x1.debug} => ${t1.debug}} {${x2.debug} => ${t2.debug}}"

  def toLatex(implicit o: IOptions): String = {
    postProcess(
      s"\\casee{${t.toLatex}}{${x1.toLatex}}{${t1.toLatex}}{${x2.toLatex}}{${t2.toLatex}}"
    )
  }

  override val subTerms = Seq(t, t1, t2)

  def derivationName = "TYP-CASE"
}

/** A derivation tree of a hole
  */
case class IHole() extends TypeDerivation {
  def tpe = HoleType()

  def pprint = "[]"

  def toLatex(implicit o: IOptions): String = "[]"

  def derivationName = "E[]"
}

/** Tag to mark a subtree as in Checked mode */
trait IChecked extends TypeDerivation

/** Tag to mark a serious subtree as in Checked mode */
trait ICheckedSerious extends IChecked

/** Tag to mark a value subtree as in Checked mode */
trait ICheckedValue extends IChecked

/** A derivation tree of a lambda abstraction
  * @param x The variable to bind
  * @param t The term to bind the variable to
  * @param ty The type of the lambda
  */
case class ILambda(x: IVar, t: TypeDerivation, ty: GType)
    extends SimpleValue
    with ICheckedValue {

  def tpe = {
    if (t.tpe eq cod(ty)) ty
    else throw new ITypeError(t, t.tpe, cod(ty))
  }

  def pprint = "(" + lambdaS.pprint + x.pprint + ". " + t.pprint + s")"

  override def debug = "(" + lambdaS.pprint + x.debug + ". " + t.debug + s")"

  def toLatex(implicit o: IOptions): String = postProcess(
    "(\\lambda " + x.toLatex + ". " + t.toLatex + s")"
  )

  override val subTerms = Seq(t)

  def derivationName = "TY-Abs"

  override val mode = 2
}

/** A derivation tree of a fixpoint
  * @param x The variable to bind
  * @param t The term to bind the variable to
  * @param ty The type of the fixpoint
  */
case class IFix(x: IVar, t: TypeDerivation, ty: GType) extends ICheckedSerious {

  def tpe = {
    if (t.tpe eq ty) ty
    else throw new ITypeError(t, t.tpe, ty)
  }

  def pprint = "(fix " + x.pprint + ". " + t.pprint + s")"

  override def debug = "(fix " + x.debug + ". " + t.debug + s")"

  def toLatex(implicit o: IOptions): String = postProcess(
    s"\\fix{${x.toLatex}}{${t.toLatex}}"
  )

  override val subTerms = Seq(t)

  def derivationName = "Typ-fix"

  override val mode = 2
}

/** A derivation tree of the subsumption rule TYP-SUB
  * @param t The term to check
  * @param b The type to check against
  */
case class Sub(t: TypeDerivation, b: GType) extends ICheckedSerious {
  def tpe = {
    val a = t.tpe
    if (a <~ b)
      /** here we check for consistent subtyping!! * */
      b
    else {
      throw new ITypeError(t, a, b)
    }
  }

  override val mode = 2

  override val subTerms = Seq(t)

  override def judgments(g: RuntimeEnvironment) = Seq(CSubtyping(t.tpe, b))

  override def derivationName: String = "TYP-cs"

  override def toLatex(implicit o: IOptions): String = t.toLatex

  def pprint: String = t.pprint

  override def debug = s"(${t.pprint} <=v)"
}

/** A derivation tree of the subsumption rule TYP-SUB for values to avoid infinite reduction
  * @param t The value to check
  * @param b The type to check against
  */
case class SubValue(t: TypeDerivation, b: GType) extends ICheckedValue {
  def tpe = {
    val a = t.tpe
    if (a <~ b)
      b
    else {
      //println(s"el term es ${t}")
      //println(s"es aca ${a}, ${b}")
      throw new ITypeError(t, a, b)
    }
  }

  override val mode = 2

  override val subTerms = Seq(t)

  override def judgments(g: RuntimeEnvironment) = Seq(CSubtyping(t.tpe, b))

  override def derivationName: String = "TYP-cs"

  override def toLatex(implicit o: IOptions): String = t.toLatex

  def pprint: String = s"${t.pprint}"

  override def debug = s"(${t.pprint} <=)"
}

/** A derivation tree of the application rule TYP-RT
  * @param t1 The function to apply
  * @param t2 The argument to apply the function to
  */
case class IAppRT(t1: ILambda, t2: TypeDerivation) extends ICheckedSerious {
  def tpe = {
    t2.tpe
    cod(t1.tpe)
  }

  override val mode = 2

  override val subTerms = Seq(t1, t2)

  override def derivationName: String = "Typ-rt"

  override def toLatex(implicit o: IOptions): String =
    s"${t1.toLatex}${t2.toLatex}"

  def pprint: String = s"${t1.pprint}${t2.pprint}"

  override def debug: String = s"${t1.pprint}${t2.pprint} <="
}

/** companion object with several important functions used to typecheck. */
object TypeDerivation {

  /** This function checks if a value is a function
    * @param v The value to check
    * @return True if the value is a function, false otherwise
    */
  def isFunction(v: TypeDerivation): Boolean = {
    v match {
      case IAscVal(SubValue(f, _), ty: FuncType) => isFunction(f)
      case IAscVal(f: ILambda, ty: FuncType)     => isFunction(f)
      case f: ILambda                            => true
      case _                                     => false
    }
  }

  /** This function merge two results if there is no ambiguity (see paper).
    * @param r1 The first result
    * @param r2 The second result
    * @return The merged result
    */
  def ∨(r1: IResult, r2: IResult): IResult = {
    (r1, r2) match {
      case (v1: IValue, v2: IValue) if v1 == v2 => v1
      case (v1: IValue, v2: IValue) if v1 != v2 =>
        IErrorA(s"In ∨, between ${v1.pprint} and ${v2.pprint}")
      case (_: IErrorT, r) => r
      case (r, _: IErrorT) => r
      case (r: IErrorA, _) => r
      case (_, r: IErrorA) => r
      case _               => throw new Error("∨ match error")
    }
  }

  /** This function creates a new merge from two results if both results are not error
    * @param r1 The first result
    * @param r2 The second result
    * @return The merged result
    */
  def ∧(r1: IResult, r2: IResult): IResult = {
    (r1, r2) match {
      case (v1: IValue, v2: IValue) => IMergeValue(v1, v2)
      case (_: IErrorA, _: IErrorA) => IErrorA(s"In ∧")
      case (r: IErrorT, _)          => r
      case (_, r: IErrorT)          => r
      case (r: IErrorA, v: IValue)  => r
      case (v: IValue, r: IErrorA)  => r
      case _                        => throw new Error("∧ match error")
    }
  }

  /** This function checks if a value is a ground value or not
    * @param v The value to check
    * @return True if the value is ground, false otherwise
    */
  def isGround(v: IValue): Boolean = {
    v match {
      case ITop()     => true
      case _: INumber => true
      case _: IBool   => true
      case _: IUnit   => true
      case _: ITop    => true
      //case ILambda(x, e, ty) => ty.isGround
      case IAscVal(_, FuncType(Unknown(), Unknown())) => true
      case IRecordValue(_, IAscVal(SubValue(g: IValue, _), Unknown())) =>
        isGround(g)
      case IMergeValue(
            IAscVal(SubValue(g1: IValue, _), Unknown()),
            IAscVal(SubValue(g2: IValue, _), Unknown())
          ) =>
        isGround(g1) && isGround(g2)
      case IPairValue(
            IAscVal(SubValue(g1: IValue, _), Unknown()),
            IAscVal(SubValue(g2: IValue, _), Unknown())
          ) =>
        isGround(g1) && isGround(g2)
      case IInj1Value(IAscVal(SubValue(g1: IValue, _), Unknown()), _) =>
        isGround(g1)
      case _ => false
    }
  }

  /** This function checks if a value is an ordinary value or not
    * @param v The value to check
    * @return True if the value is ordinary, false otherwise
    */
  def isOrdinary(v: IValue): Boolean = {
    v match {
      case ITop()                           => true
      case _: INumber                       => true
      case _: IBool                         => true
      case _: IUnit                         => true
      case _: ILambda                       => true
      case _: ITop                          => true
      case IAscVal(_, ty: FuncType)         => true
      case IRecordValue(_, _: IValue)       => true
      case IPairValue(_: IValue, _: IValue) => true
      case IInj1Value(_: IValue, _)         => true
      case IInj2Value(_: IValue, _)         => true
      case _                                => false
    }
  }

  /** One of the main functions.
    * This function casts a value to a given type. See Fig. 8 of paper.
    * @param v The value to cast
    * @return The result of the cast, wich can be another value or an error.
    */
  def cast(v: IValue, a: GType): IResult = {
    //println(s"Casting ${v.pprint} to ${a.pprint}")
    val r = (v, a) match {
      case (_, TopType())          => ITop()
      case (n: INumber, IntType()) => n
      case (b: IBool, BoolType())  => b
      case (u: IUnit, UnitType())  => u
      case (IRecordValue(l1, v), RecordType(l2, a)) if l1 == l2 => {
        cast(v, a) match {
          case vp: IValue => IRecordValue(l1, vp)
          case x          => x
        }
      }
      case (IPairValue(v1: IValue, v2: IValue), PairType(a1, a2)) => {
        val r1 = cast(v1, a1)
        val r2 = cast(v2, a2)
        (cast(v1, a1), cast(v2, a2)) match {
          case (v1p: IValue, v2p: IValue) => IPairValue(v1p, v2p)
          case (e1: IRuntimeException, _) => e1
          case (_, e2: IRuntimeException) => e2
          case _                          => throw new Error("Pair match error")
        }
      }
      case (IInj1Value(v: IValue, a), SumType(a1, a2)) => {
        cast(v, a1) match {
          case vp: IValue => IInj1Value(vp, a2)
          case x          => x
        }
      }
      case (IInj2Value(v: IValue, a), SumType(a1, a2)) => {
        cast(v, a2) match {
          case vp: IValue => IInj2Value(vp, a1)
          case x          => x
        }
      }

      case (f, ty: FuncType) if f.tpe <~ ty && isFunction(f) => {
        IAscVal(SubValue(f, ty), ty)
      }
      case (IMergeValue(v1, v2), a: Ordinary) => {
        val r1 = cast(v1, a)
        val r2 = cast(v2, a)
        ∨(r1, r2)
      }
      case (v, IntersectionType(a, b)) => {
        val r1 = cast(v, a)
        val r2 = cast(v, b)
        ∧(r1, r2)
      }
      case (s, Unknown()) if isOrdinary(s) => {
        cast(s, s.tpe.ground) match {
          case v: IValue => IAscVal(SubValue(v, Unknown()), Unknown())
          case x         => x
        }
      }

      case (IMergeValue(v1, v2), Unknown()) => {
        (cast(v1, Unknown()), cast(v2, Unknown())) match {
          case (v1p: IValue, v2p: IValue) =>
            IAscVal(SubValue(IMergeValue(v1p, v2p), Unknown()), Unknown())
          case _ => throw new Error("Impossible!")
        }
      }

      case (x @ IAscVal(SubValue(g: IValue, _), Unknown()), Unknown())
          if isGround(g) =>
        x

      case (IAscVal(SubValue(g: IValue, _), Unknown()), a: Ordinary)
          if isGround(g) =>
        cast(g, a)

      case (v, a) if !(v.tpe <~ a) => IErrorT()

      case (v, BotType()) => IErrorT()

      case _ => throw new Error(s"Can't cast ${v} to ${a}")
    }
    //println(s"result ${r}")
    r
  }

  /** This function substitutes a variable by a value in a term.
    * The implementation is straightforward and proceeds by case analysis on term e.
    * @param e The term to substitute
    * @param x The variable to substitute
    * @param v The value to substitute
    * @return The term with the substitution
    */
  def subst(e: TypeDerivation, x: IVar, v: TypeDerivation): TypeDerivation = {
    e match {
      case IVar(y, ty) if x.x == y         => v
      case IVar(y, ty)                     => IVar(y, ty)
      case IAscVal(e, ty)                  => IAscVal(subst(e, x, v), ty)
      case ILambda(y, e, ty) if x.x == y.x => ILambda(y, e, ty)
      case ILambda(y, e, ty)               => ILambda(y, subst(e, x, v), ty)
      case IFix(y, e, ty) if x.x == y.x    => IFix(y, e, ty)
      case IFix(y, e, ty)                  => IFix(y, subst(e, x, v), ty)
      case IApp(e1, e2)                    => IApp(subst(e1, x, v), subst(e2, x, v))
      case IAppRT(e1, e2) =>
        IAppRT(subst(e1, x, v).asInstanceOf[ILambda], subst(e2, x, v))
      case IBool(b)       => IBool(b)
      case INumber(n)     => INumber(n)
      case IUnit()        => IUnit()
      case ITop()         => ITop()
      case IMerge(e1, e2) => IMerge(subst(e1, x, v), subst(e2, x, v))
      case IMergeValue(e1, e2) =>
        IMergeValue(
          subst(e1, x, v).asInstanceOf[IValue],
          subst(e2, x, v).asInstanceOf[IValue]
        )
      case IRecord(l, e) => IRecord(l, subst(e, x, v))
      case IRecordValue(l, e) =>
        IRecordValue(l, subst(e, x, v).asInstanceOf[IValue])
      case IProj(e, l)     => IProj(subst(e, x, v), l)
      case IAsc(e, ty)     => IAsc(subst(e, x, v), ty)
      case Sub(e, ty)      => Sub(subst(e, x, v), ty)
      case SubValue(e, ty) => SubValue(subst(e, x, v), ty)
      case IIntIntIntOp(e1, e2, op) =>
        IIntIntIntOp(subst(e1, x, v), subst(e2, x, v), op)
      case IIntIntBoolOp(e1, e2, op) =>
        IIntIntBoolOp(subst(e1, x, v), subst(e2, x, v), op)
      case IBoolOp(e1, e2, op)           => IBoolOp(subst(e1, x, v), subst(e2, x, v), op)
      case IBoolUnOp(e, op)              => IBoolUnOp(subst(e, x, v), op)
      case ILet(y, e1, e2) if x.x == y.x => ILet(y, subst(e1, x, v), e2)
      case ILet(y, e1, e2)               => ILet(y, subst(e1, x, v), subst(e2, x, v))
      case IIte(e1, e2, e3) =>
        IIte(subst(e1, x, v), subst(e2, x, v), subst(e3, x, v))
      case IInj1(e, ty)       => IInj1(subst(e, x, v), ty)
      case IInj1Value(e, ty)  => IInj1Value(subst(e, x, v), ty)
      case IInj2(e, ty)       => IInj2(subst(e, x, v), ty)
      case IInj2Value(e, ty)  => IInj2Value(subst(e, x, v), ty)
      case IPair(e1, e2)      => IPair(subst(e1, x, v), subst(e2, x, v))
      case IPairValue(e1, e2) => IPairValue(subst(e1, x, v), subst(e2, x, v))
      case ICase(e, y1, e1, y2, e2) =>
        ICase(subst(e, x, v), y1, subst(e1, x, v), y2, subst(e2, x, v))

      case _ => throw new Error(s"subst match error for ${e}")
    }
  }
}
