package glang.typing

import glang.syntax.GTypes._
import glang.syntax.Syntax._
import glang.syntax._
import glang.typing.TypeDerivation._

/** Bidirectional type checking algorithm.
  * This object contains the implementation of the elaboration algorithm that builds a type derivation tree from an AST.
  * This algorithm inserts some needed annotations in the program to remove non-determinism of typing.
  * For instance (\x. x) is ambiguous, but (\x. x : T -> T) is not.
  */
object Typing {

  /** Exception thrown when a variable cannot be found.
    *
    * @param t The term that caused the exception.
    */
  class VariableNotFoundException(t: Term)
      extends Error("Can't find type for variable " + t.pprint)

  /** Exception thrown for invalid subtyping relations.
    *
    * @param t1 The first type in the subtyping relation.
    * @param t2 The second type in the subtyping relation.
    */
  class ITypeError(t: Term, found: GType, required: GType)
      extends Error(
        "Type mismatch in \"" + t.pprint + "\": Found " + found.pprint + ", required " + required.pprint + "."
      )

  /** Exception thrown when types are not disjoint.
    *
    * @param t The term that caused the exception.
    * @param a The first type.
    * @param b The second type.
    */
  class IDisjointError(t: Term, a: GType, b: GType)
      extends Error(
        s"Type error in ${t.pprint}: ${a.pprint} is not disjoint to ${b.pprint}"
      )

  /** Exception thrown for stack errors.
    */
  class StackError extends Error("stack error!")

  /** Creates a frame with a term, environment, and type in check mode.
    *
    * @param t   The term.
    * @param env The environment.
    * @param ty  The type to check against.
    * @return A new Frame instance.
    */
  def c(t: Term, env: Environments, ty: GType) = Frame(t, env, Check(ty))

  /** Creates a frame with a term, environment, and typing mode (either check or infer).
    *
    * @param t    The term.
    * @param env  The environment.
    * @param mode The type direction.
    * @return A new Frame instance.
    */
  def c(t: Term, env: Environments, mode: TypeDirection) = Frame(t, env, mode)

  /** Applies a term and environment to create an type derivation.
    *
    * @param t   The term.
    * @param env The environment.
    * @return A type derivation term
    */
  def apply(t: Term, env: Environments = Environments()): TypeDerivation =
    apply(List(Frame(t, env, Infer)), List())

  /** Trait representing the direction of type checking.
    */
  trait TypeDirection {
    def pprint: String
  }

  /** Case object representing inference mode.
    */
  case object Infer extends TypeDirection {
    def pprint = "=>"
  }

  /** Case class representing check mode, checking against a specific type.
    *
    * @param ty The type to check against.
    */
  case class Check(ty: GType) extends TypeDirection {
    def pprint = "<="
  }

  /** Case class representing a frame of a term with an environment and type direction.
    *
    * @param t    The term.
    * @param env  The environment.
    * @param mode The type direction.
    */
  case class Frame(t: Term, env: Environments, mode: TypeDirection) {
    def pprint = t.pprint + mode.pprint
  }

  /** Convert a stack of frames into a stack of type derivations.
    * Initially the stack is full and istack is empty.
    * The algorithm ends when stack is empty.
    *
    * @param stack  The list of frames. The input of the algorithm
    * @param istack The list of type derivations. The output of the algorithm
    * @return An type derivation.
    */
  def apply(
      stack: List[Frame],
      istack: List[TypeDerivation]
  ): TypeDerivation = {

    stack match {
      case Nil => istack.headOption.getOrElse(throw new StackError)

      /** typ-rt
        * IN:
        * stack: (\x. []) [], ...
        * istack: e, v, ...
        * OUT:
        * stack: ...
        * istack: (\x, v) e, ...
        */
      case Frame(App(Lambda(x, Hole()), Hole()), _, Check(_)) :: xs =>
        istack match {
          case ix1 :: ix2 :: ixs =>
            apply(
              xs,
              IAppRT(
                ILambda(IVar(x.x, ix2.tpe), ix1, FuncType(ix2.tpe, ix1.tpe)),
                ix2
              ) :: ixs
            )
        }
      /** typ-rt
        * We use the type of v to type check the body of the lambda.
        * IN:
        * stack: (\x. e) [], ...
        * istack: v, ...
        * OUT:
        * stack: ...
        * istack: v, ...
        */
      case Frame(App(Lambda(x, t), Hole()), env, m @ Check(b)) :: xs =>
        istack match {
          case ix :: ixs =>
            val a = ix.tpe
            val extEnv = env.extend(x -> a)
            apply(
              c(t, extEnv, Check(b)) :: c(
                App(Lambda(x, Hole()), Hole()),
                env,
                m
              ) :: xs,
              istack
            )
        }

      /** typ-rt
        * We are in checked mode therefore we must type check the argument in order to typcheck the body of the lambda.
        * IN:
        * stack: (\x. e) e2, ...
        * istack: ...
        * OUT:
        * stack: e2, (\x. e) [], ...
        * istack: ...
        */
      case Frame(App(Lambda(x, t), t2), env, m @ Check(_)) :: xs => {
        apply(
          c(t2, env, Infer) :: c(App(Lambda(x, t), Hole()), env, m) :: xs,
          istack
        )
      }

      /** typ-Abs
        * IN:
        * stack: (\x. []) [], ...
        * istack: e,...
        * OUT:
        * stack: ...
        * istack: (\x. e), ...
        */
      case Frame(Lambda(x, Hole()), env, Check(a)) :: xs =>
        istack match {
          case ix :: ixs => {
            apply(xs, ILambda(IVar(x.x, dom(a)), ix, a) :: ixs)
          }
        }
      /** typ-Abs
        * IN:
        * stack: (\x. e) [], ...
        * istack: ...
        * OUT:
        * stack: e, (\x. []) [], ...
        * istack: ...
        */
      case Frame(Lambda(x, t), env, Check(ty)) :: xs => {
        val a1 = dom(ty)
        val a2 = cod(ty)
        val extEnv = env.extend(x -> a1)
        apply(
          c(t, extEnv, Check(a2)) :: c(Lambda(x, Hole()), env, Check(ty)) :: xs,
          istack
        )
      }

      /** special rule to insert unknown annotation
        * IN:
        * stack: (\x. e) [], ...
        * istack: ...
        * OUT:
        * stack: (\x. e): * -> *, ...
        * istack: ...
        */
      case Frame(Lambda(x, t), env, Infer) :: xs => {
        apply(
          c(
            Asc(Lambda(x, t), FuncType(Unknown(), Unknown())),
            env,
            Infer
          ) :: xs,
          istack
        )
      }

      /** typ-fix
        * IN:
        * stack: (fix x. []) [], ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: (fix x. e), ...
        */
      case Frame(Fix(x, Hole()), env, Check(a)) :: xs =>
        istack match {
          case ix :: ixs => {
            apply(xs, IFix(IVar(x.x, a), ix, a) :: ixs)
          }
        }

      /** typ-fix
        * IN:
        * stack: (fix x. e) [], ...
        * istack: ...
        * OUT:
        * stack: e, (fix x. []) [], ...
        * istack: ...
        */
      case Frame(Fix(x, t), env, Check(ty)) :: xs => {
        val extEnv = env.extend(x -> ty)
        apply(
          c(t, extEnv, Check(ty)) :: c(Fix(x, Hole()), env, Check(ty)) :: xs,
          istack
        )
      }

      /** special rule to insert unknown annotation
        * IN:
        * stack: (fix x. e) [], ...
        * istack: ...
        * OUT:
        * stack: (fix x. e): *, ...
        * istack: ...
        */
      case Frame(Fix(x, t), env, Infer) :: xs => {
        apply(c(Asc(Fix(x, t), Unknown()), env, Infer) :: xs, istack)
      }

      /** Typ-cs
        * This case is to explicitly mark when we are using the subsumption rule
        * IN:
        * stack: [] <= T, ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: e <= T, ...
        */
      case Frame(Hole(), _, Check(ty)) :: xs =>
        istack match {
          case ix :: ixs => apply(xs, Sub(ix, ty) :: ixs)
        }

      /** Typ-sub
        * This case is to explicitly mark when we are using the subsumption rule
        * IN:
        * stack: e <= T, ...
        * istack: ...
        * OUT:
        * stack: e => T', [] <= T, ...
        * istack: ...
        */
      case Frame(t, env, Check(ty)) :: xs => {
        apply(c(t, env, Infer) :: c(Hole(), env, Check(ty)) :: xs, istack)
      }

      /** Typ-lit
        * IN:
        * stack: x, ...
        * istack: ...
        * OUT:
        * stack: ...
        * istack: x, ...
        */
      case Frame((t: Bool), env, Infer) :: xs =>
        apply(xs, IBool(t.b) :: istack)

      /** Typ-lit
        * IN:
        * stack: x, ...
        * istack: ...
        * OUT:
        * stack: ...
        * istack: x, ...
        */
      case Frame((t: Number), env, Infer) :: xs =>
        apply(xs, INumber(t.v) :: istack)

      /** Typ-lit
        * IN:
        * stack: x, ...
        * istack: ...
        * OUT:
        * stack: ...
        * istack: x, ...
        */
      case Frame((t: UnitVal), env, Infer) :: xs =>
        apply(xs, IUnit() :: istack)

      /** Typ-top
        * IN:
        * stack: x, ...
        * istack: ...
        * OUT:
        * stack: ...
        * istack: x, ...
        */
      case Frame((t: Top), env, Infer) :: xs => apply(xs, ITop() :: istack)

      /** Typ-var
        * This fails if the variable is not found in the environment
        * IN:
        * stack: x, ...
        * istack: ...
        * OUT:
        * stack: ...
        * istack: x, ...
        */
      case Frame((t: Var), env, Infer) :: xs => {
        val ty =
          (env.te.lookup(t).getOrElse(throw new VariableNotFoundException(t)))
        apply(xs, IVar(t.x, ty) :: istack)
      }

      /** IN:
        * stack: [] op [], ...
        * istack: e2, e1, ...
        * OUT:
        * stack: ...
        * istack: e1 op e2...
        */
      case Frame(BoolOp(Hole(), Hole(), op), env, Infer) :: xs =>
        istack match { //Elimination
          case ix2 :: ix1 :: ixs =>
            apply(xs, IBoolOp(ix1, ix2, op) :: ixs)
          case _ => throw new StackError
        }

      /** IN:
        * stack: e1 op e2, ...
        * istack: ...
        * OUT:
        * stack: e1, e2, [] op [], ...
        * istack: ...
        */
      case Frame(BoolOp(t1, t2, op), env, Infer) :: xs =>
        apply(
          c(t1, env, BoolType()) :: c(t2, env, BoolType()) :: c(
            BoolOp(Hole(), Hole(), op),
            env,
            Infer
          ) :: xs,
          istack
        )

      /** IN:
        * stack: op [], ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: op e...
        */
      case Frame(BoolUnOp(Hole(), op), env, Infer) :: xs =>
        istack match { //Elimination
          case ix1 :: ixs =>
            apply(xs, IBoolUnOp(ix1, op) :: ixs)
          case _ => throw new StackError
        }

      /** IN:
        * stack: op e, ...
        * istack: ...
        * OUT:
        * stack: e, op [], ...
        * istack: ...
        */
      case Frame(BoolUnOp(t1, op), env, Infer) :: xs =>
        apply(
          c(t1, env, BoolType()) :: c(BoolUnOp(Hole(), op), env, Infer) :: xs,
          istack
        )

      /** IN:
        * stack: [] op [], ...
        * istack: e2, e1, ...
        * OUT:
        * stack: ...
        * istack: e1 op e2...
        */
      case Frame(IntIntBoolOp(Hole(), Hole(), op), env, Infer) :: xs =>
        istack match { //Elimination
          case ix2 :: ix1 :: ixs =>
            apply(xs, IIntIntBoolOp(ix1, ix2, op) :: ixs)
          case _ => throw new StackError
        }

      /** IN:
        * stack: e1 op e2, ...
        * istack: ...
        * OUT:
        * stack: e1, e2, [] op [], ...
        * istack: ...
        */
      case Frame(IntIntBoolOp(t1, t2, op), env, Infer) :: xs =>
        apply(
          c(t1, env, IntType()) :: c(t2, env, IntType()) :: c(
            IntIntBoolOp(Hole(), Hole(), op),
            env,
            Infer
          ) :: xs,
          istack
        )

      /** IN:
        * stack: [] op [], ...
        * istack: e2, e1, ...
        * OUT:
        * stack: ...
        * istack: e1 op e2...
        */
      case Frame(IntIntIntOp(Hole(), Hole(), op), env, Infer) :: xs =>
        istack match { //Elimination
          case ix2 :: ix1 :: ixs =>
            apply(xs, IIntIntIntOp(ix1, ix2, op) :: ixs)
          case _ => throw new StackError
        }

      /** IN:
        * stack: e1 op e2, ...
        * istack: ...
        * OUT:
        * stack: e1, e2, [] op [], ...
        * istack: ...
        */
      case Frame(IntIntIntOp(t1, t2, op), env, Infer) :: xs =>
        apply(
          c(t1, env, IntType()) :: c(t2, env, IntType()) :: c(
            IntIntIntOp(Hole(), Hole(), op),
            env,
            Infer
          ) :: xs,
          istack
        )

      /** IN:
        * stack: ([], []), ...
        * istack: e2, e1...
        * OUT:
        * stack: ...
        * istack: (e1,e2)...
        */
      case Frame(GPair(Hole(), Hole()), env, Infer) :: xs =>
        istack match { //Elimination
          case ix2 :: ix1 :: ixs => apply(xs, IPair(ix1, ix2) :: ixs)
          case _                 => throw new StackError
        }

      /** IN:
        * stack: (e1, e2), ...
        * istack: ...
        * OUT:
        * stack: e1, e2, ([],[]), ...
        * istack: ...
        */
      case Frame(GPair(t1, t2), env, Infer) :: xs =>
        apply(
          c(t1, env, Infer) :: c(t2, env, Infer) :: c(
            GPair(Hole(), Hole()),
            env,
            Infer
          ) :: xs,
          istack
        )

      /** typ-merge
        * IN:
        * stack: [],, [], ...
        * istack: e2, e1...
        * OUT:
        * stack: ...
        * istack: e1,,e2, ...
        */
      case Frame(Merge(Hole(), Hole()), env, Infer) :: xs =>
        istack match { //Elimination
          case ix2 :: ix1 :: ixs => apply(xs, IMerge(ix1, ix2) :: ixs)
          case _                 => throw new StackError
        }

      /** typ-merge
        * IN:
        * stack: e1,, e2, ...
        * istack: ...
        * OUT:
        * stack: e1,, e2, [],,[], ...
        * istack: ...
        */
      case Frame(Merge(t1, t2), env, Infer) :: xs =>
        apply(
          c(t1, env, Infer) :: c(t2, env, Infer) :: c(
            Merge(Hole(), Hole()),
            env,
            Infer
          ) :: xs,
          istack
        )

      /** IN:
        * stack: inj1 [], ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: inj1 e, ...
        */
      case Frame(Inj1(Hole(), tpe), env, Infer) :: xs =>
        istack match { //Elimination
          case ix :: ixs => apply(xs, IInj1(ix, tpe) :: ixs)
          case _         => throw new StackError
        }

      /** IN:
        * stack: inj1 e, ...
        * istack: ...
        * OUT:
        * stack: e, inj1 [], ...
        * istack: ...
        */
      case Frame(Inj1(t, tpe), env, Infer) :: xs =>
        apply(
          c(t, env, Infer) :: c(Inj1(Hole(), tpe), env, Infer) :: xs,
          istack
        )
      /** same as inj1 */
      case Frame(Inj2(Hole(), tpe), env, Infer) :: xs =>
        istack match { //Elimination
          case ix :: ixs => apply(xs, IInj2(ix, tpe) :: ixs)
          case _         => throw new StackError
        }
      /** same as inj1 */
      case Frame(Inj2(t, tpe), env, Infer) :: xs =>
        apply(
          c(t, env, Infer) :: c(Inj2(Hole(), tpe), env, Infer) :: xs,
          istack
        )

      /** IN:
        * stack: if [] then [] else [], ...
        * istack: e3, e2, e1...
        * OUT:
        * stack: ...
        * istack: if e1 then e2 else e3...
        */
      case Frame(Ite(Hole(), Hole(), Hole()), env, Infer) :: xs =>
        istack match {
          case it3 :: it2 :: it1 :: ixs => {
            apply(xs, IIte(it1, it2, it3) :: ixs)
          }
          case _ => throw new StackError
        }

      /** IN:
        * stack: if e1 then e2 else e3, ...
        * istack: ...
        * OUT:
        * stack: e1, e2, e3 if [] then [] else [], ...
        * istack: ...
        */
      case Frame(Ite(t1, t2, t3), env, Infer) :: xs =>
        apply(
          c(t1, env, BoolType()) :: c(t2, env, Infer) :: c(t3, env, Infer) :: c(
            Ite(Hole(), Hole(), Hole()),
            env,
            Infer
          ) :: xs,
          istack
        )

      /** typ-app
        * IN:
        * stack: [] [], ...
        * istack: e2, e1 ...
        * OUT:
        * stack: ...
        * istack: e1 e2, ...
        */
      case Frame(App(Hole(), Hole()), _, Infer) :: xs =>
        istack match {
          case it2 :: it1 :: ixs => {
            apply(xs, IApp(it1, it2) :: ixs)
          }
          case _ => throw new StackError
        }

      /** typ-app
        * IN:
        * stack: [] e2, ...
        * istack: e1, ...
        * OUT:
        * stack: e2, [] [], ...
        * istack: e1, ...
        */
      case Frame(App(Hole(), t2), env, Infer) :: xs =>
        istack match {
          case ix :: ixs =>
            apply(
              c(t2, env, dom(ix.tpe)) :: c(
                App(Hole(), Hole()),
                env,
                Infer
              ) :: xs,
              istack
            )
          case _ => throw new StackError
        }

      /** typ-app
        * IN:
        * stack: e1 e2, ...
        * istack: ...
        * OUT:
        * stack: e1, [] e2, ...
        * istack: ...
        */
      case Frame(App(t1, t2), env, Infer) :: xs =>
        apply(c(t1, env, Infer) :: c(App(Hole(), t2), env, Infer) :: xs, istack)

      /** typ-anno
        * IN:
        * stack: [] :: T, ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: e :: T, ...
        */
      case Frame(Asc(Hole(), t), env, Infer) :: xs =>
        istack match {
          case ie :: ixs => {
            apply(xs, IAsc(ie, t) :: ixs)
          }
          case _ => throw new StackError
        }

      /** typ-anno
        * IN:
        * stack: e :: T, ...
        * istack: ...
        * OUT:
        * stack: e, [] :: T, ...
        */
      case Frame(Asc(e, ot), env, Infer) :: xs => {
        apply(c(e, env, ot) :: c(Asc(Hole(), ot), env, Infer) :: xs, istack)
      }

      /** typ-rcd
        * IN:
        * stack: {l=[]}, ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: {l=e}, ...
        */
      case Frame(Record(l, Hole()), env, Infer) :: xs =>
        istack match {
          case it :: ixs =>
            apply(xs, IRecord(l, it) :: ixs)
          case _ =>
            throw new StackError
        }

      /** typ-rcd
        * IN:
        * stack: {l=e}, ...
        * istack: ...
        * OUT:
        * stack: e, {l=[]}...
        * istack: ...
        */
      case Frame(Record(l, t), env, Infer) :: xs =>
        apply(
          c(t, env, Infer) :: c(Record(l, Hole()), env, Infer) :: xs,
          istack
        )

      /** typ-proj
        * IN:
        * stack: [].l, ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: e.l, ...
        */
      case Frame(Proj(Hole(), l), env, Infer) :: xs =>
        istack match {
          case it :: ixs =>
            apply(xs, IProj(it, l) :: ixs)
          case _ =>
            throw new StackError
        }

      /** typ-proj
        * IN:
        * stack: e.l, ...
        * istack: ...
        * OUT:
        * stack: e, [].l...
        * istack: ...
        */
      case Frame(Proj(t, l), env, Infer) :: xs =>
        apply(c(t, env, Infer) :: c(Proj(Hole(), l), env, Infer) :: xs, istack)

      /** IN:
        * stack: let _ = [] in [], ...
        * istack: e2, x, e1, ...
        * OUT:
        * stack: ...
        * istack: let x = e1 in e2, ...
        */
      case Frame(Let(_, Hole(), Hole()), env, Infer) :: xs =>
        istack match {
          case it2 :: (ix: IVar) :: it1 :: ixs => {
            apply(xs, ILet(ix, it1, it2) :: ixs)
          }
          case _ => throw new StackError
        }

      /** IN:
        * stack: let x = [] in e2, ...
        * istack: e1, ...
        * OUT:
        * stack: e2, let x = [] in [], ...
        * istack: e1, ...
        */
      case Frame(Let(x, Hole(), t2), env, Infer) :: xs =>
        istack match {
          case it1 :: ixs => {
            val newEnv = env.extend(x -> it1.tpe)
            apply(
              c(x, newEnv, Infer) :: c(t2, newEnv, Infer) :: c(
                Let(x, Hole(), Hole()),
                env,
                Infer
              ) :: xs,
              istack
            )
          }
          case _ => throw new StackError
        }

      /** IN:
        * stack: let x = e1 in e2, ...
        * istack: ...
        * OUT:
        * stack: e1, let x = [] in e2, ...
        * istack: ...
        */
      case Frame(Let(x, t1, t2), env, Infer) :: xs =>
        apply(
          c(t1, env, Infer) :: c(Let(x, Hole(), t2), env, Infer) :: xs,
          istack
        )

      /** IN:
        * stack first [], ...
        * istack: e, ...
        * OUT:
        * stack: ...
        * istack: fst e, ...
        */
      case Frame(First(Hole()), env, Infer) :: xs =>
        istack match {
          case it :: ixs =>
            val tpe = it.tpe
            apply(xs, IFirst(it) :: ixs)
          case _ => throw new StackError
        }

      /** IN:
        * stack: fst e, ...
        * istack: ...
        * OUT:
        * stack: e, fst [], ...
        * istack: ...
        */
      case Frame(First(t), env, Infer) :: xs =>
        apply(c(t, env, Infer) :: c(First(Hole()), env, Infer) :: xs, istack)

      /** analogous to First */
      case Frame(Second(Hole()), env, Infer) :: xs =>
        istack match {
          case it :: ixs =>
            val tpe = it.tpe
            apply(xs, ISecond(it) :: ixs)
          case _ => throw new StackError
        }
      /** analogous to First */
      case Frame(Second(t), env, Infer) :: xs =>
        apply(c(t, env, Infer) :: c(Second(Hole()), env, Infer) :: xs, istack)

      /** IN:
        * stack: case [] of x1 => [] | x2 => [], ...
        * istack: e2, x2, e1, x1, e, ...
        * OUT:
        * stack: ...
        * istack: case e of x1 => e1 | x2 => e2, ...
        */
      case Frame(Case(Hole(), _, Hole(), _, Hole()), env, Infer) :: xs =>
        istack match {
          case it2 :: (ix2: IVar) :: it1 :: (ix1: IVar) :: it :: ixs => {
            apply(xs, ICase(it, ix1, it1, ix2, it2) :: ixs)
          }
          case _ => throw new StackError
        }

      /** IN:
        * stack: case [] of x1 => e1 | x2 => e2, ...
        * istack: e, ...
        * OUT:
        * stack: x1, e1, x2, e2, case [] of [] => [] | [] => [], ...
        * istack: e, ...
        */
      case Frame(Case(Hole(), x1, t1, x2, t2), env, Infer) :: xs =>
        istack match {
          case it :: ixs => {
            val t = it.tpe
            val ty1 = pis1(t)
            val ty2 = pis2(t)
            val newEnv1 = env.extend(x1 -> ty1)
            val newEnv2 = env.extend(x2 -> ty2)
            apply(
              c(x1, newEnv1, Infer) :: c(t1, newEnv1, Infer) :: c(
                x2,
                newEnv2,
                Infer
              ) :: c(t2, newEnv2, Infer) :: c(
                Case(Hole(), x1, Hole(), x2, Hole()),
                env,
                Infer
              ) :: xs,
              istack
            )
          }
          case _ => throw new StackError
        }

      /** IN:
        * stack: case e of x1 => e1 | x2 => e2, ...
        * istack: ...
        * OUT:
        * stack: e, case [] of x1 => e1 | x2 => e2, ...
        * istack: ...
        */
      case Frame(Case(t, x1, t1, x2, t2), env, Infer) :: xs =>
        apply(
          c(t, env, Infer) :: c(Case(Hole(), x1, t1, x2, t2), env, Infer) :: xs,
          istack
        )

      /** default case is an error
        */
      case c => throw new Error("Typing not implemented for " + c)
    }

  }

}
