package controllers

import javax.inject._
import glang.runtime.Runtime._
import glang.syntax.Syntax.TypeError
import play.api.libs.json.{Json, Writes}
import play.api.mvc._

import scala.concurrent.{ExecutionContext, Future}
import glang.{runtime, _}
import glang.runtime.SubstitutionModel
import glang.typing.{IConfLatex, IOptions, LatexDerivationTree, LatexJudgment, Typing}
import play.api.mvc._
import play.api.libs.json._
import play.api.libs.functional.syntax._
import glang.typing.Typing._
import play.api.Play
import glang.typing.TypeDerivation._

//import scala.pickling.Defaults._, scala.pickling.json._

case class Program(
    lang: Int = 2,
    program: String,
    substitutionMode: Int = 0,
    hideTypes: Boolean = false,
    hideEvidences: Boolean = false,
    pc: String = "L",
    fromStep: Int = 0,
    implicitPolymorphism: Boolean = false
)

import glang.syntax.Syntax._

/** This is the controller of the web application */
@Singleton
class ApplicationController @Inject() (
    cc: MessagesControllerComponents,
    config: play.api.Configuration
)(implicit ec: ExecutionContext)
    extends MessagesAbstractController(cc) {

  implicit val fReads = Json.reads[Program]
  implicit val judgmentWrites = Json.writes[LatexJudgment]
  implicit val derivationTreeWrites = Json.writes[LatexDerivationTree]

  implicit val confWrites = Json.writes[IConfLatex]
  def index(prod: Int) = Action { implicit request =>
    val v = config.get[String]("version")
    Ok(views.html.index(prod, v))
  }
  def formatInput(s: String): String = {
    symbols.foldLeft(s) {
      case (acc, s) => {
        acc.replace(s.pprint, s.parser)
      }
    }
  }
  /** this is the first endpoint to type check a program */
  def typecheck = Action { request: Request[AnyContent] =>
    val fResult = request.body.asJson.get.validate[Program]
    fResult.fold(
      errors => {
        BadRequest(
          Json.obj("status" -> "KO", "message" -> JsError.toJson(errors))
        )
      },
      f => {

        Parser.parse(formatInput(f.program)) match {
          case Right(term) =>
            try {
              //println(s"parsed ${term}")
              implicit val o = IOptions()
              val iterm = Typing((term))
              //println(s"elaborated ${iterm}")
              val latex = iterm.toLatex
              val tree = iterm.getLatexDerivationTree

              Ok(
                Json.obj(
                  "status" -> "OK",
                  "program" -> f.program,
                  "intrinsicTerm" -> latex,
                  "tree" -> Json.toJson(tree)
                )
              )
            } catch {
              case e: VariableNotFoundException =>
                Ok(Json.obj("status" -> "KO", "error" -> e.getMessage))
              case e: TypeError =>
                Ok(Json.obj("status" -> "KO", "error" -> e.getMessage))
              case e: Throwable =>
                Ok(Json.obj("status" -> "KO", "error" -> e.getMessage))
            }

          case Left(error) =>
            Ok(Json.obj("status" -> "KO", "error" -> ("Parse error: " + error)))
        }

      }
    )
  }

  /** this is the second endpoint to reduce a program */
  def reduce = Action { request: Request[AnyContent] =>
    val fResult = request.body.asJson.get.validate[Program]
    fResult.fold(
      errors => {
        BadRequest(
          Json.obj("status" -> "KO", "message" -> JsError.toJson(errors))
        )
      },
      f => {
        Parser.parse(formatInput(f.program)) match {
          case Right(term) =>
            try {
              implicit val o = IOptions()
              val reducer = runtime.Runtime.Reducer(
                Typing((term)),
                fromStep = f.fromStep
              )(SubstitutionModel(f.substitutionMode), o)

              val r = reducer.reduce

              val error: Option[String] = r.r match {
                case Left(a)  => None
                case Right(e) => Some(e.getMessage())
              }

              val confs = r.configurations
              Ok(
                Json.obj(
                  "status" -> "OK",
                  "program" -> f.program,
                  "confs" -> Json.toJson(confs.drop(f.fromStep)),
                  "error" -> Json.toJson(error),
                  "finished" -> Json.toJson(r.finished),
                  "step" -> Json.toJson(r.step)
                )
              )

            } catch {
              case e: VariableNotFoundException =>
                Ok(Json.obj("status" -> "KO1", "error" -> e.getMessage))
              case e: TypeError =>
                Ok(Json.obj("status" -> "KO2", "error" -> e.getMessage))
              case e: Throwable =>
                println(e)
                Ok(Json.obj("status" -> "KO3", "error" -> e.getMessage))
            }
          case Left(error) => Ok("Parse error: " + error)
        }

      }
    )
  }
}
