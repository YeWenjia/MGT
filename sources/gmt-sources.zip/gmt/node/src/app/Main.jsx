/**
 * In this file, we create a React component
 * which incorporates components providedby material-ui.
 */

import React from 'react';
import PropTypes from 'prop-types';
import {createTheme, MuiThemeProvider as MuiThemeProviderNext, withStyles,} from '@material-ui/core/styles';
import {MuiPickersUtilsProvider} from '@material-ui/pickers';
import indigo from '@material-ui/core/colors/indigo';
import pink from '@material-ui/core/colors/pink';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Index from './Index'
import {HashRouter, Route, Switch} from 'react-router-dom';

export const theme = createTheme({
  palette: {
    primary: indigo,
    secondary: pink,
    type: 'light',

    /*primary: {
      main: '#003A7E'
    },*/
    /*secondary: {
        main: '#0087C0'
    },*/
  },
  typography: {
    // In Japanese the characters are usually larger.
    //fontSize: 10,
  },
  spacing: 4,
})

const thresshold = 768

class Main extends React.Component {
  static contextTypes = {
    router : PropTypes.object
  }

  constructor(props, context) {
    super(props, context);
    
    this.handleTouchTapLeftIconButton = this.handleTouchTapLeftIconButton.bind(this);
    this.handleChangeRequestNavDrawer = this.handleChangeRequestNavDrawer.bind(this);
    this.handleRequestChangeList = this.handleRequestChangeList.bind(this);

    this.handleResize = this.handleResize.bind(this);
    window.addEventListener('resize', this.handleResize);

    this.state = {
      navDrawerOpen: window.innerWidth>thresshold,
      navDrawerDocked: window.innerWidth>thresshold,
      isDeviceSize: window.innerWidth<=thresshold
    };

  }

  handleResize() {
    this.setState({navDrawerDocked: window.innerWidth >= thresshold, isDeviceSize: window.innerWidth < thresshold})
    /*if(this.state.navDrawerOpen && window.innerWidth < thresshold)
      this.setState({navDrawerOpen: false, isDeviceSize: true, navDrawerDocked: false});
    else if(!this.state.navDrawerOpen && window.innerWidth >= thresshold)
      this.setState({navDrawerOpen: true, isDeviceSize: false, navDrawerDocked: true});

     */
  }


  handleTouchTapLeftIconButton() {
    this.setState({
      navDrawerOpen: !this.state.navDrawerOpen,
    });
  }

  handleChangeRequestNavDrawer(open) {
    this.setState({
      navDrawerOpen: open,
    });
  }

  handleRequestChangeList(event, value) {
    this.context.router.push(value);
    this.setState({
      navDrawerOpen: false,
    });
  }


  getStyles = () => {
    const styles = {
      root: {
        minHeight: 400,
      }
    }
    return styles
  }

  isDeviceSize = (size) => {
    if(this.state.isDeviceSize && size == styleResizable.statics.Sizes.LARGE)
      return false;
    else return true;
  }

  handleRequestChangeList = (event, value) => {
    this.context.router.push(value);
    this.setState({
      navDrawerOpen: false,
    });
  }

  onRequestChange = (open) => {
    this.setState({navDrawerOpen: open});
  }
  render() {
    
    let showMenuIconButton = true;
    const styles = this.getStyles();




    return (
      <div>
      <MuiThemeProviderNext theme={theme}>
        <div>
          <div className="main" style={styles.root}>
            <AppBar position="static">
              <Toolbar>
                <Typography variant="h6">
                  λM*: Gradual Merge Types
                </Typography>
              </Toolbar>
            </AppBar>

            <div className="content" >
              <Switch>
                <Route path="/:example" component={Index}/>
                <Route path="/" component={Index}/>
              </Switch>
            </div>
          </div>
        </div>
      </MuiThemeProviderNext>
      </div>
    );
  }
}

export default Main;
