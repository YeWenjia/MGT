import React from 'react';
import ReactDOM from 'react-dom';
//import injectTapEventPlugin from 'react-tap-event-plugin';

import AppRoutes from './AppRoutes';


require('./../www/main.css'); 
//injectTapEventPlugin();


ReactDOM.render(<AppRoutes/>, document.getElementById('app'));

module.hot.accept()