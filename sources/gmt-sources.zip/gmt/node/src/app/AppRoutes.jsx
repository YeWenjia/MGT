
import React from 'react';
import { render } from 'react-dom';
import {HashRouter, Route, Switch} from 'react-router-dom';
//import { Router, Route, Link, browserHistory, useRouterHistory, IndexRoute } from 'react-router';
import {createHashHistory} from 'history';
//import Index from './Index';
import Main from './Main';
import PropTypes from "prop-types";

const history = createHashHistory({window: window})




class Foo extends React.Component{
    render(){
        return (<div>Foo</div>);
    }
}

class AppRoutes extends React.Component {
    static childContextTypes = {
        router: PropTypes.object
    }

    getChildContext() {
        return {router: history};
    }


    render() {
        return (
            <div>
                <HashRouter>
                    <Switch>
                        <Route path="/" component={Main}/>
                    </Switch>
                </HashRouter>
            </div>
        );
    }
}
export default AppRoutes;