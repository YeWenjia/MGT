import React from 'react';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import request from 'superagent';
import Subheader from '@material-ui/core/ListSubheader';
import LoadableContent from './components/LoadableContent';
import PropTypes from 'prop-types';

import DerivationTree from './DerivationTree';
//import ArrowDownward from '@material-ui/core/svg-icons/navigation/arrow-downward';
import ArrowDownward from '@material-ui/icons/ArrowDownward'

//import RErrorIcon from '@material-ui/core/svg-icons/social/sentiment-very-dissatisfied.js';
import RErrorIcon from '@material-ui/icons/SentimentVeryDissatisfied';


import red from '@material-ui/core/colors/red';

import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import SvgIcon from '@material-ui/core/SvgIcon';
import IconButton from '@material-ui/core/IconButton';
import Dialog from '@material-ui/core/Dialog';

import AceEditor from 'react-ace';


import "ace-builds/src-noconflict/mode-ocaml";
import "ace-builds/src-noconflict/theme-github";

//import 'brace/mode/ocaml';
//import 'brace/theme/chrome';

const red500 = red['500'];
class MyTextField extends React.Component{
	oldIdx = 0
	oldLength = 0


	render(){
		//return (<TextField {...this.props} />);
		return (
			<div style={{paddingTop: 8}}>
				<AceEditor
				    mode="ocaml"
				    theme="github"
				    name="UNIQUE_ID_OF_DIV"
				    value={this.props.value}
				    onChange={this.props.onChange}
				    editorProps={{$blockScrolling: true}}
				    height={'200px'}
				    width={'100%'}
				    style={{}}
				  />
				  {this.props.errorText?
				  <div style={{color: red500, fontSize: "120%", }} id={"errorBox"}>
				  	{this.props.errorText}
				  </div>:null}
	  		</div>
	  )
	}
}
const HelpIcon = (props) => (
  <SvgIcon {...props}>
    <path d="M0 0h24v24H0z" fill="none"/>
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>
  </SvgIcon>
);

const empty = {text: " -- Select an example from this list to load it in the scratchpad --" +
        "", desc: ""}


const examples = [
    empty,
	{text: "Paper Section 2.2. Introducing the merge operator", program: "let x = 1,,true in (x+1, ¬x)", desc: "In the following program, x has both an integer and a boolean value and has the type Int & Bool. When x is used, it can be used as either an integer or a boolean"},
	//{text: "Paper Section 2.2. Type-directed Semantics of Merges and the Interaction with Subtyping", program: "let x = 1,,true in (x+1, ¬x)", desc: "λM*  is sound with respect to subtyping"},
	{text: "Paper Section 2.2. Disjoint Intersection Types", program: "((λx.((x,,1)+1)):bool -> int) (true,,2)", desc: "If we just substitute true,,2v with a normal beta " +
"reduction, a non-disjoint expression would be generated after substitution (true,,2v,,1v). Instead, true is extracted by casting true,,2v" +
"under the function input type bool. Thus the value that gets substituted in the body of the lambda is true instead of true,,2v."},
	{text: "Paper Section 2.3. Circle mixin part 1/2", program: "let pi = 3 in\n" +
			"let circle = (λsuper. super,, {area = (λradius. pi * radius * radius): int -> int}) in\n" +
			"let c = circle({perimeter = (λradius. 2 * pi * radius) : int -> int}) in\n" +
			"(c.area(10), c.perimeter(10))", desc:"This program illustrates a simplified encoding of dynamic inheritance. The following circle constructor can be extended with any other class."},
	{text: "Paper Section 2.3. Circle mixin part 2/2", program: "let pi = 3 in\n" +
			"let circle = (λsuper. super,, {area = (λradius. pi * radius * radius): int -> int}) in\n" +
			"let c = circle({area = (λradius. 2 * pi * radius) : int -> int}) in\n" +
			"(c.area(10), c.perimeter(10))", desc:"Now if we extend circle with another class that also has an area method, then the program fails with an ambiguity error."},
	{text: "Paper section 2.4. Cast combination strategy", program: "λx. (x ,, true) : int -> int & bool : int -> (int & T) : int -> int", desc: ""},
	{text: "Paper section 2.4. Ambiguity Errors and Type Errors part 1/3", program: "(1 : ★,, 2 : ★) : int", desc: "This program reduces to an error. Otherwise the reduction would be non-deterministic and we could choose any of the two integers, which is undesirable."},
	{text: "Paper section 2.4. Ambiguity Errors and Type Errors part 2/3", program: "(true : ★,, 1 : ★) : int", desc: "This program reduces succesfully to 1."},
	{text: "Paper section 2.4. Ambiguity Errors and Type Errors part 3/3", program: "((1 : ★,, 2 : ★) : ★,,3 : ★) : int", desc: "As the left component reduces to an ambiguity error, we propagate this error to the whole expression and reduce to an ambiguity error."},
	{text: "Paper section 2.4. Encoding the GTFL Calculus part 1/3", program: "(({l1 = 1},, {l2 = true}) : {l1 : int} & {l2 : bool}).l2", desc: "This program reduces succesfully to true."},
	{text: "Paper section 2.4. Encoding the GTFL Calculus part 2/3", program: "(({l1 = 1},, {l2 = true}) : {l1 : int} & ★).l2", desc: "This program reduces succesfully to true cast to ★."},
	{text: "Paper section 2.4. Encoding the GTFL Calculus part 3/3", program: "let f = (λx. λy. x ,, y) in\n" +
			"(f {l1 = 1}) {l1 = 2}", desc: "We allow concatenating two records with unknown fields at runtime. Therefore we dynamically check ambiguity errors at runtime. This program reduces successfully but fails if the resulting merge is projected to l1."},
	{text: "Paper section 2.4. Modular Type-based Invariants", program: "(({l1 = 5},, {l2 = true}) : ★ : {l1: int} : ★ : {l1: int} & {l2: bool}).l2", desc: "This program reduces to a type error since the record no longer contains l2 at the moment of the projection."},
	{text: "Paper section 2.4. Counterexample of the DGG part 1/2", program: "((1,,true):int,, (2,,false):bool) : bool", desc: "This program reduces succesfully to false."},
	{text: "Paper section 2.4. Counterexample of the DGG part 2/2", program: "((1,,true):★,, (2,,false):★) : bool", desc: "This program doesn't know from where to extract the bool value so it reduces to an ambiguity error."},
	{text: "Encoding of classes", program: "let class = (λx. fix self. ({foo = (λx. self.bar): int -> int},,{bar = 2}) : {foo: int -> int} & {bar: int}) : unit -> {foo: int -> int} & {bar: int} in\n" +
			"let obj = (class ()) : {foo: int -> int} in\n" +
			"obj.foo 1", desc: ""},


]
const examplesItems = examples.map((e, i) => {
	return <MenuItem key={i} value={i}>{e.text}</MenuItem>
});

export default class Main extends React.Component {
	static contextTypes = {
        router : PropTypes.object.isRequired
    }
	constructor(props, context){
		super(props, context)
		this.state = {
			formula: "bar",
			program:  this.getProgram(props).program,// props.match.params.example?this.findProgramByValue(props.match.params.example).program:this.findProgramByValue(1).program, //"if true_H::Bool_?  then ref 10_L else ref 20_L",//"(λx: Ref Int.\n    (λy: Unit. !x) (x := 10)\n) (ref 4)",
			desc: this.getProgram(props).desc,//props.match.params.example?this.findProgramByValue(props.match.params.example).desc:this.findProgramByValue(1).desc,
			intrinsicTerm: "",
			intrinsicTermList: [],
			tree: null,
			loadingI: false,
			loadingT: false,
			loadingR: false,
			loadingRE: false,
			confs: [],
			error: "",
			substitutionMode: 0,
			hideTypes: true,
			hideEvidences: true,
			implicitPolymorphism: false,
			rerror: "",
			defaultProgram: (props.match.params.example && this.findProgramByValue(props.match.params.example))?parseInt(props.match.params.example):0,
			pc: "B",
			fromStep: 0,
			newSteps: 0,
			finished: true,
			reducing: false,
			syntaxOpen: false,
			showLabels: false,
			hideSyntax: false
		}


	}




	getProgram(props){
		return (props.match.params.example && this.findProgramByValue(props.match.params.example))? this.findProgramByValue(props.match.params.example) : this.findProgramByValue(0)
	}
	componentWillReceiveProps(nextProps) {
		if(nextProps.match.params.example != this.props.match.params.example){
			const example = this.getProgram(nextProps);

			this.setState({program: example.program || '', desc: example.desc, defaultProgram: (nextProps.match.params.example && this.findProgramByValue(nextProps.match.params.example))?parseInt(nextProps.match.params.example):0})
		}
	}



    handleWindowResize = () => {
        this.setState({ showLabels: window.innerWidth >= 1185, hideSyntax:  window.innerWidth < 1080});
    }
    componentWillMount(){
        this.handleWindowResize();
	}
    componentDidMount() {
        window.addEventListener('resize', this.handleWindowResize);

    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.handleWindowResize);
    }


	onChange = (e, v) => {
		if(!this.math)
			this.math = MathJax.Hub.getAllJax("toLatex")[0]
		this.setState({formula: v}, () => {
			//MathJax.Hub.Queue(["Typeset",MathJax.Hub, "toLatex"]);
			MathJax.Hub.Queue(["Text",this.math,this.state.formula])
		});
	}

	guessPlusSymbol = (c) => {
		v.split("")
	}
	onChangeProgram = (v) => {
		this.setState({program: v.
			replace("\\", "λ").
			replace("and", "∧").
			replace("or","∨").
			replace("inf","∞").
			//replace("*", "⋆").
			replace("?", "★").
			replace("dyn", "★").
			replace("not", "¬").
			replace("neg", "¬")})
	}

	findProgramByValue(v) {
		return examples.filter((e,i) => i == v)[0]
	}
	changeDefaultProgram = (event, index) => {
		this.setState({confs: [], tree: null, intrinsicTerm: null, rerror: null}, () => {
            this.context.router.push('/'+event.target.value)
		})



	};

	intrinsify = (e, cb) => {
		if(this.state.program && this.state.program.trim().length>0){
			this.setState({loadingI: true, loadingT: true, confs: [], tree: null, error: "", rerror: null, fromStep: 0, finished: true, newSteps: 0, reducing: false}, () => {
				request.post('typecheck')
				.send({program: this.state.program, substitutionMode: this.state.substitutionMode, hideTypes: this.state.hideTypes, hideEvidences: this.state.hideEvidences, lang: 1, fromStep: this.state.fromStep, pc: "L", implicitPolymorphism: this.state.implicitPolymorphism})
				.set('Accept', 'application/json')
				.end((err, res) => {
					if (err || !res.ok) {
					   alert('Oh no! error');
					} else {
						if(res.body.status=="OK") {
							this.setState({
								intrinsicTerm: "$$" + res.body.intrinsicTerm + "$$",
								tree: res.body.tree
							}, () => {

								MathJax.Hub.Queue(["Typeset", MathJax.Hub, "intrinsicTerm"], () => this.setState({loadingI: false}));
								MathJax.Hub.Queue(["Typeset", MathJax.Hub, "derivationTree"], () => this.setState({loadingT: false}));

								if(cb)
									cb()
							})
						}
						else{
							this.setState({error: res.body.error, loadingI: false, loadingT: false, intrinsicTerm: ""}, () => {
								MathJax.Hub.Queue(["Typeset", MathJax.Hub, "errorBox"]);
							});



						}
					}
				});
			});
		}

	}

	reduce = () => {
		this.setState({loadingR: true, loadingRE: true, rerror: null, newSteps: this.state.fromStep}, () => {
			request.post('reduce')
			.send({program: this.state.program, substitutionMode: this.state.substitutionMode, hideTypes: this.state.hideTypes, hideEvidences: this.state.hideEvidences, lang: 1, fromStep: this.state.fromStep, pc: "L", implicitPolymorphism: this.state.implicitPolymorphism, })
	        .set('Accept', 'application/json')
	        .end((err, res) => {
	            if (err || !res.ok) {
	               alert('Oh no! error');
	            } else {
                    if(res.body.status=="OK"){
                        this.setState({confs: this.state.confs.concat(res.body.confs.slice(1)), rerror: res.body.error, finished: res.body.finished, fromStep: res.body.step, reducing: true}, () => {
                            //this.setState({loadingR: false});
							//var conclusions = document.getElementsByClassName('.dtree>.infer>.conclusion')
                            MathJax.Hub.Queue(["Typeset",MathJax.Hub, "reduce"], () => this.setState({loadingR: false}));
							MathJax.Hub.Queue(["Typeset", MathJax.Hub, "reduceError"], () => this.setState({loadingRE: false}));
                        })
                    } else{
                        this.setState({error: res.body.error,loadingR: false, loadingRE: false, loadingI: false, loadingT: false, intrinsicTerm: "", tree: null});
                    }
	            }
	        });
		});
	}


    onToggle = (e,v) => {
        this.setState({substitutionMode: v?0:1}, () => {
            if(this.state.tree) this.reduce();
        });

    }
	onToggleHideType = (e,v) => {
		this.setState({hideTypes: !v}, () => {
			if(this.state.tree) this.intrinsify();
		});

	}

	onToggleHideEvidences = (e,v) => {
		this.setState({hideEvidences: !v}, () => {
			if(this.state.tree) {
                this.intrinsify(e, this.state.reducing?this.reduce:null);
            }


		});

	}

    onToggleImplicitPolymorphism = (e,v) => {

        this.setState({implicitPolymorphism: v}, () => {
            if(this.state.tree) {
                this.intrinsify(e, this.state.reducing?this.reduce:null);
            }


        });

    }



	 syntaxHandleOpen = () => {
	    this.setState({syntaxOpen: true});
	  };

	  syntaxHandleClose = () => {
	    this.setState({syntaxOpen: false});
	  };



	render(){
        const { isMobile } = this.state;

		const confs = this.state.confs.map((c,i) => {
			//store={c.store}
			return (<div key={"reduce"+i} style={{display: (this.state.newSteps<=i && this.state.loadingR)?'none':''}}>
				<ArrowDownward style={{marginTop:'8px'}}/>
				<DerivationTree tree={c.tree}
								substitutionMode={this.state.substitutionMode} key={"dtree"+i} shouldUpdate={this.state.newSteps<=i}/>
			</div>);
		});
		const syntax = (showLabels) => <div>
            <table>
                <tbody>
                <tr>
                    <td>A</td>
                    <td>::=</td>
                    <td>Int | Bool | A -> B |  </td>
                    <td></td>
                </tr>
				<tr>
					<td></td>
					<td></td>
					<td>{"{l : A}"} | A & B | A x B | {"★"} </td>
					<td>{showLabels?"(Gradual Types)":""}</td>
				</tr>
                <tr>
                    <td>b</td>
                    <td>::=</td>
                    <td>true | false</td>
                    <td>{showLabels?"(Booleans)":""}</td>
                </tr>
                <tr>
                    <td>n</td>
                    <td>::=</td>
                    <td>natural numbers</td>
                    <td>{showLabels?"(Natural numbers)":""}</td>
                </tr>
                <tr>
                    <td>e</td>
                    <td>::=</td>
                    <td>x | b | n | () | {"e < e"} | {"e+e"} | {"e-e"} | {"e*e"} |</td>
                    <td></td>
                </tr>
				<tr>
					<td></td>
					<td></td>
					<td>(λx.e) | {"e e"} | {"fix x. e"}</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td> {"(e,e)"} | {"fst e"} | {"snd e"} </td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td> {"{}"} | {"{l = e}"} | {" e.l"} | {"e ,, e"}</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td> {"{let x = e in e}"}</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td> {"inl{A} e"} | {"inr{A} e"} | {"case e of {x => e} {x => e}"}</td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td> e : A | {"¬e"} |  if e then e else e </td>
					<td>{showLabels?"(Expressions)":""}</td>
				</tr>
                </tbody>
            </table>

            {"To write the \"λ\" character, type \"\\\""}.<br/>
            {"To write the \"★\" character, type \"?\""}.<br/>
			{"To write the \"¬\" character, type \"not\""}.<br/>


		</div>
		return (
			<Paper style={{padding:'8px'}}>


				<Dialog
		          title="Syntax"
				  onClose={this.syntaxHandleClose}
		          actions={[<Button
					        primary={true}
					        onTouchTap={this.syntaxHandleClose}
				  >Close</Button>]}
		          modal={false}
		          open={this.state.syntaxOpen}
		          onRequestClose={this.syntaxHandleClose}
		        >
					<div style={{padding: 20}}>
						{syntax(true)}
					</div>
		        </Dialog>


				<div className="form" style={{position: "relative"}}>
					<FormControl style={{width: "100%"}}>
						<InputLabel id="demo-simple-select-label">Preloaded examples</InputLabel>
						<Select value={this.state.defaultProgram} onChange={this.changeDefaultProgram} autoWidth={true} fullWidth={true}>
							{examplesItems}
						</Select>
					</FormControl>
					<div style={{color: "rgba(0, 0, 0, 0.541176)"}}>
						{this.state.desc}
					</div>
					<div style={{position:'relative'}}>
						<div style={{display: 'flex', flexWrap: "wrap"}}>
							<div style={{flex: "1 1 626px"}}>
								<div style={{color: "rgba(0, 0, 0, 0.54)", fontSize: "0.875rem", fontWeight: 500, paddingTop: 16, paddingLeft: 16}}>λM* term</div>
								<MyTextField  floatingLabelText="Program"
											name="formula"
											value={this.state.program}
											multiLine={true}
											onChange={this.onChangeProgram}
											style={{width:'100%'}}
											errorText={this.state.error}
											onKeyDown={this.onKeyDown}
											ref={(c) => this._program = c}
								/>
							</div>
							{!this.state.hideSyntax?<div style={{paddingTop: 6}}>
								{syntax(this.state.showLabels)}
							</div>:null}
						</div>
						<div style={{marginTop: 8}}>
							<Button variant="contained"  color="primary"  secondary={true} onClick={this.intrinsify} >Typecheck!</Button>
							<Button style={{ marginLeft: "8px"}} onClick={() => {this.context.router.push('/0')}}>Clear scratchpad</Button>
							<Button style={{ marginLeft: "8px"}} onClick={() => {this.setState({program: this.getProgram(this.props).program})}}>Reload example</Button>
							{this.state.hideSyntax?<Button  style={{ marginLeft: "8px"}} onClick={() => {this.setState({syntaxOpen: true})}}>View Syntax</Button>:null}
						</div>
					</div>


                </div>
				{this.state.loadingI || this.state.intrinsicTerm?
					<div>
						<Subheader>λM* program</Subheader>
						<LoadableContent loading={this.state.loadingI}>

						</LoadableContent>
						<div id="intrinsicTerm"  style={{textAlign:'center', display: this.state.loadingI?'none':'', overflow: 'auto'}}>
							{this.state.intrinsicTerm}
						</div>
					</div>
					:null}
				{this.state.loadingT || this.state.tree || this.state.rerror?
					<div>
						<Subheader>λM* type derivation and reduction</Subheader>
						<LoadableContent loading={this.state.loadingT}>

						</LoadableContent>
						<div style={{textAlign:'center', display: this.state.loadingT?'none':''}}>
							<div id="derivationTree" style={{display: (this.state.confs.length>0 && !this.state.loadingR) || this.state.reducing?'none':''}}>
								<DerivationTree tree={this.state.tree} />
							</div>
							{this.state.confs.length<=0 && !this.state.rerror?
								<div style={{marginTop:'16px'}}>
									<Button variant="contained" color={"primary"} onClick={this.reduce}>Reduce!</Button>
								</div>
							:null}

                            {this.state.confs.length<=0?null:
                            <div id="reduce"  >
                                {confs}
                            </div>}
                            {this.state.rerror?
								<div>
									<RErrorIcon style={{width:100, height:100, display: this.state.loadingRE?'none':'', color: red500}} />
									<div id="reduceError" style={{color: red500, fontSize: "120%", display: this.state.loadingRE?'none':''}}>
										{this.state.rerror}
									</div>
								</div>
								:null}
							{(!this.state.finished && !this.state.loadingR && !this.state.loadingRE)?
								<div style={{marginTop:'16px'}}>
									<Button variant="contained" primary={true} onClick={this.reduce}>Reduce more steps!</Button>
								</div>
								:null
							}

							<LoadableContent loading={this.state.loadingR || this.state.loadingRE}>

							</LoadableContent>
						</div>
					</div>
				:null}

			</Paper>);
	}

}



