const webpack = require('webpack');
const path = require('path');
const buildPath = path.resolve(__dirname, 'build');
const nodeModulesPath = path.resolve(__dirname, 'node_modules');
const TransferWebpackPlugin = require('transfer-webpack-plugin');

const config = {
  entry: [path.join(__dirname, '/src/app/app.jsx')],
  resolve: {
    //When require, do not have to add these extensions to file's name
    extensions: [".js", ".jsx", ".tsx", ".ts"],
    alias: {
      process: 'process/browser',
      stream: "stream-browserify",
      zlib: "browserify-zlib"
    }
    //node_modules: ["web_modules", "node_modules"]  (Default Settings)
  },
  //Render source-map file for final build
  devtool: false,
  //output config
  output: {
    path: buildPath,    //Path of output file
    filename: 'app.js',  //Name of output file
    chunkFilename: '[name].bundle.js',
  },
  plugins: [
    //Allows error warnings but does not stop compiling. Will remove when eslint is added
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify("production")
      }
    }),
    new webpack.ProvidePlugin({
      process: 'process/browser',
      Buffer: ['buffer', 'Buffer'],
    }),
  ],
  module: {
    rules: [
      {
        //React-hot loader and
        test: /\.jsx?$/,  //All .js files
        use: [{loader: 'babel-loader'}], //react-hot is like browser sync and babel loads jsx and es6-7
        exclude: [nodeModulesPath],
      },
      {test: /\.tsx?$/, loader: 'ts-loader'},
      {
        test: /\.css$/,
        use: [{loader: 'style-loader'}, {loader: 'css-loader'}],
        include: [path.join(__dirname, 'src/www'), path.join(__dirname, 'node_modules/react-select/dist/react-select.css'), path.join(__dirname, 'node_modules/typeface-roboto/index.css'), path.join(__dirname, 'node_modules/react-virtualized/styles.css')],
        exclude: /flexboxgrid/
      },
      {
        test: /\.css$/,
        use: [{loader: 'style-loader'}, {loader: 'css-loader?modules'}],
        include: /flexboxgrid/,
      },
      {
        test: /\.(woff|woff2|eot|ttf|svg)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: 'fonts/[name].[ext]'
            }
          }
        ]
      }
    ],
  },
};

module.exports = config;
